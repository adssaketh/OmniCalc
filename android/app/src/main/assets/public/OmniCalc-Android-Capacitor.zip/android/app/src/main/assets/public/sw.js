/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "c10851e11ba6c3a95d6ed26674b6d42d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "9aaacdc977badad6984a9e26de77d0d2"
  }, {
    "url": "pwa-192x192.png",
    "revision": "0d6f50c7d8a28c8c1258661ec214c020"
  }, {
    "url": "privacy-policy.html",
    "revision": "c84100eb52c29a65f3a635eef97c6d6a"
  }, {
    "url": "index.html",
    "revision": "c06aba0b9c26890a90661a894fdf86b4"
  }, {
    "url": "icon.svg",
    "revision": "f0fad8fe2e87049d5985715500e1d51d"
  }, {
    "url": "favicon.ico",
    "revision": "76b25285e1bf830b967acb952dbc9a36"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "43462fe1b462807049c7492f1ff1c23d"
  }, {
    "url": "assets/web-CLnDBxB-.js",
    "revision": null
  }, {
    "url": "assets/web-BHyOb5iq.js",
    "revision": null
  }, {
    "url": "assets/index-CKxMLlOh.js",
    "revision": null
  }, {
    "url": "assets/index-BacFw1dk.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "43462fe1b462807049c7492f1ff1c23d"
  }, {
    "url": "favicon.ico",
    "revision": "76b25285e1bf830b967acb952dbc9a36"
  }, {
    "url": "icon.svg",
    "revision": "f0fad8fe2e87049d5985715500e1d51d"
  }, {
    "url": "pwa-192x192.png",
    "revision": "0d6f50c7d8a28c8c1258661ec214c020"
  }, {
    "url": "pwa-512x512.png",
    "revision": "9aaacdc977badad6984a9e26de77d0d2"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "c10851e11ba6c3a95d6ed26674b6d42d"
  }, {
    "url": "fonts/jetbrains-mono-500.ttf",
    "revision": "4bbe069455d3664c677f3aed2ae52ea3"
  }, {
    "url": "fonts/jetbrains-mono-600.ttf",
    "revision": "45fff87b3c3d556cbe5c03c45e71862a"
  }, {
    "url": "fonts/outfit-400.ttf",
    "revision": "55d5785290b1b79416f2d979bb627738"
  }, {
    "url": "fonts/outfit-600.ttf",
    "revision": "5d10e86057713398adb241ac22568b12"
  }, {
    "url": "fonts/outfit-700.ttf",
    "revision": "4fa2a7180a009d0a93eaa11d736aed50"
  }, {
    "url": "manifest.webmanifest",
    "revision": "bc9174d28ab181183a34e6fe16d6972b"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 15,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 30,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
