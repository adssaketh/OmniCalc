import { AngleMode } from '../types';

export class MathEvaluator {
  private static sanitizeExpression(expr: string): string {
    return expr
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/√\(/g, 'sqrt(')
      .replace(/√([0-9.a-zA-Zπe]+)/g, 'sqrt($1)')
      .replace(/³√\(/g, 'cbrt(')
      .replace(/³√([0-9.a-zA-Zπe]+)/g, 'cbrt($1)')
      .replace(/π/g, ' PI ')
      .replace(/\bhbar\b|ħ/g, ' 1.054571817e-34 ')
      .replace(/\bh\b/g, ' 6.62607015e-34 ')
      .replace(/\bc\b/g, ' 299792458 ')
      .replace(/\bG\b/g, ' 6.67430e-11 ')
      .replace(/\bqe\b|\bq_e\b/g, ' 1.602176634e-19 ')
      .replace(/\bme\b|\bm_e\b/g, ' 9.1093837e-31 ')
      .replace(/\bmp\b|\bm_p\b/g, ' 1.67262192e-27 ')
      .replace(/\bkB\b|\bk_B\b/g, ' 1.380649e-23 ')
      .replace(/\bNA\b|\bN_A\b/g, ' 6.02214076e23 ')
      .replace(/\beps0\b|ε₀|ε0/g, ' 8.8541878128e-12 ')
      .replace(/\bmu0\b|μ₀|μ0/g, ' 1.256637062e-6 ')
      .replace(/\bke\b/g, ' 8.9875517923e9 ')
      .replace(/\bg\b/g, ' 9.80665 ')
      .replace(/\be\b/g, ' E ')
      .replace(/φ/g, ' PHI ')
      .trim();
  }

  // Preprocess implicit multiplications like "2(3)" -> "2*(3)", "5sin(30)" -> "5*sin(30)", "(2)(3)" -> "(2)*(3)"
  private static addImplicitMultiplication(tokens: string[]): string[] {
    const output: string[] = [];
    const isNumOrConst = (t: string) => /^(\d+(\.\d+)?([eE][+-]?\d+)?|PI|E|PHI)$/.test(t);
    const isCloseParen = (t: string) => t === ')';
    const isOpenParen = (t: string) => t === '(';
    const isFunc = (t: string) => /^(sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|ln|log|log2|sqrt|cbrt|abs|round|floor|ceil)$/.test(t);

    for (let i = 0; i < tokens.length; i++) {
      const curr = tokens[i];
      output.push(curr);

      if (i < tokens.length - 1) {
        const next = tokens[i + 1];
        if (
          (isNumOrConst(curr) && (isOpenParen(next) || isFunc(next) || isNumOrConst(next))) ||
          (isCloseParen(curr) && (isOpenParen(next) || isNumOrConst(next) || isFunc(next))) ||
          (curr === '!' && (isOpenParen(next) || isNumOrConst(next) || isFunc(next)))
        ) {
          output.push('*');
        }
      }
    }
    return output;
  }

  // Tokenize math expression into tokens
  private static tokenize(expr: string): string[] {
    const raw = this.sanitizeExpression(expr);
    const regex = /\d+(\.\d+)?([eE][+-]?\d+)?|PI|E|PHI|sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|ln|log2|log|sqrt|cbrt|abs|round|floor|ceil|\+|-|\*|\/|\^|%|!|\(|\)/gi;
    const matches = raw.match(regex);
    if (!matches) return [];
    return this.addImplicitMultiplication(matches);
  }

  private static factorial(n: number): number {
    if (n < 0 || !Number.isInteger(n)) throw new Error('Factorial requires non-negative integer');
    if (n === 0 || n === 1) return 1;
    if (n > 170) return Infinity; // JS number overflow
    let res = 1;
    for (let i = 2; i <= n; i++) res *= i;
    return res;
  }

  // Shunting-Yard Parser to RPN
  private static toRPN(tokens: string[], angleMode: AngleMode): (string | number)[] {
    const output: (string | number)[] = [];
    const opStack: string[] = [];

    const precedence: Record<string, number> = {
      '+': 1,
      '-': 1,
      '*': 2,
      '/': 2,
      '%': 2,
      '^': 4,
      'u-': 5, // unary minus
      '!': 6,
    };

    const isRightAssociative = (op: string) => op === '^' || op === 'u-';

    const isFunc = (t: string) => /^(sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|ln|log|log2|sqrt|cbrt|abs|round|floor|ceil)$/i.test(t);

    let prevToken: string | null = null;

    for (let i = 0; i < tokens.length; i++) {
      let token = tokens[i];

      // Handle constants
      if (token === 'PI') {
        output.push(Math.PI);
        prevToken = token;
        continue;
      }
      if (token === 'E') {
        output.push(Math.E);
        prevToken = token;
        continue;
      }
      if (token === 'PHI') {
        output.push(1.618033988749895);
        prevToken = token;
        continue;
      }

      // Handle numbers (including scientific notation like 6.626e-34)
      if (/^\d+(\.\d+)?([eE][+-]?\d+)?$/i.test(token)) {
        const num = parseFloat(token);
        if (isNaN(num)) throw new Error(`Invalid number: ${token}`);
        output.push(num);
        prevToken = token;
        continue;
      }

      // Handle unary minus
      if (token === '-' && (prevToken === null || prevToken === '(' || '+-*/^%'.includes(prevToken))) {
        token = 'u-';
      }

      // Handle functions
      if (isFunc(token)) {
        opStack.push(token.toLowerCase());
        prevToken = token;
        continue;
      }

      // Handle factorial postfix
      if (token === '!') {
        output.push('!');
        prevToken = token;
        continue;
      }

      // Handle operators
      if (token in precedence) {
        while (
          opStack.length > 0 &&
          opStack[opStack.length - 1] !== '(' &&
          (isFunc(opStack[opStack.length - 1]) ||
            precedence[opStack[opStack.length - 1]] > precedence[token] ||
            (precedence[opStack[opStack.length - 1]] === precedence[token] && !isRightAssociative(token)))
        ) {
          output.push(opStack.pop()!);
        }
        opStack.push(token);
        prevToken = token;
        continue;
      }

      if (token === '(') {
        opStack.push('(');
        prevToken = token;
        continue;
      }

      if (token === ')') {
        while (opStack.length > 0 && opStack[opStack.length - 1] !== '(') {
          output.push(opStack.pop()!);
        }
        if (opStack.length === 0) {
          throw new Error('Mismatched parentheses');
        }
        opStack.pop(); // remove '('

        if (opStack.length > 0 && isFunc(opStack[opStack.length - 1])) {
          output.push(opStack.pop()!);
        }
        prevToken = token;
        continue;
      }

      throw new Error(`Unexpected token: ${token}`);
    }

    while (opStack.length > 0) {
      const top = opStack.pop()!;
      if (top === '(' || top === ')') {
        throw new Error('Mismatched parentheses');
      }
      output.push(top);
    }

    return output;
  }

  // Evaluate RPN expression
  private static evaluateRPN(rpn: (string | number)[], angleMode: AngleMode): number {
    const stack: number[] = [];

    const toRad = (val: number) => (angleMode === 'deg' ? (val * Math.PI) / 180 : val);
    const toAngle = (radVal: number) => (angleMode === 'deg' ? (radVal * 180) / Math.PI : radVal);

    for (const token of rpn) {
      if (typeof token === 'number') {
        stack.push(token);
      } else if (token === 'u-') {
        if (stack.length < 1) throw new Error('Invalid syntax');
        const a = stack.pop()!;
        stack.push(-a);
      } else if (token === '!') {
        if (stack.length < 1) throw new Error('Invalid syntax');
        const a = stack.pop()!;
        stack.push(this.factorial(a));
      } else if (['+', '-', '*', '/', '^', '%'].includes(token)) {
        if (stack.length < 2) throw new Error('Invalid syntax');
        const b = stack.pop()!;
        const a = stack.pop()!;
        let res = 0;
        switch (token) {
          case '+':
            res = a + b;
            break;
          case '-':
            res = a - b;
            break;
          case '*':
            res = a * b;
            break;
          case '/':
            if (b === 0) throw new Error('Division by zero');
            res = a / b;
            break;
          case '^':
            res = Math.pow(a, b);
            break;
          case '%':
            res = a % b;
            break;
        }
        stack.push(res);
      } else {
        // Unary function
        if (stack.length < 1) throw new Error('Invalid function call');
        const a = stack.pop()!;
        let res = 0;
        switch (token) {
          case 'sin':
            res = Math.sin(toRad(a));
            // Fix small floating point approximations e.g. sin(180 deg) -> 0
            if (Math.abs(res) < 1e-14) res = 0;
            break;
          case 'cos':
            res = Math.cos(toRad(a));
            if (Math.abs(res) < 1e-14) res = 0;
            break;
          case 'tan': {
            const rad = toRad(a);
            const cosVal = Math.cos(rad);
            if (Math.abs(cosVal) < 1e-14) throw new Error('Undefined (tan 90°)');
            res = Math.tan(rad);
            if (Math.abs(res) < 1e-14) res = 0;
            break;
          }
          case 'asin':
            if (a < -1 || a > 1) throw new Error('Domain error (asin)');
            res = toAngle(Math.asin(a));
            break;
          case 'acos':
            if (a < -1 || a > 1) throw new Error('Domain error (acos)');
            res = toAngle(Math.acos(a));
            break;
          case 'atan':
            res = toAngle(Math.atan(a));
            break;
          case 'sinh':
            res = Math.sinh(a);
            break;
          case 'cosh':
            res = Math.cosh(a);
            break;
          case 'tanh':
            res = Math.tanh(a);
            break;
          case 'ln':
            if (a <= 0) throw new Error('Domain error (ln)');
            res = Math.log(a);
            break;
          case 'log':
            if (a <= 0) throw new Error('Domain error (log)');
            res = Math.log10(a);
            break;
          case 'log2':
            if (a <= 0) throw new Error('Domain error (log2)');
            res = Math.log2(a);
            break;
          case 'sqrt':
            if (a < 0) throw new Error('Domain error (sqrt negative)');
            res = Math.sqrt(a);
            break;
          case 'cbrt':
            res = Math.cbrt(a);
            break;
          case 'abs':
            res = Math.abs(a);
            break;
          case 'round':
            res = Math.round(a);
            break;
          case 'floor':
            res = Math.floor(a);
            break;
          case 'ceil':
            res = Math.ceil(a);
            break;
          default:
            throw new Error(`Unknown function: ${token}`);
        }
        stack.push(res);
      }
    }

    if (stack.length !== 1) {
      throw new Error('Evaluation error');
    }

    return stack[0];
  }

  // Public evaluation method
  public static evaluate(expr: string, angleMode: AngleMode = 'deg'): number {
    const clean = expr.trim();
    if (!clean) return 0;
    const tokens = this.tokenize(clean);
    if (tokens.length === 0) return 0;
    const rpn = this.toRPN(tokens, angleMode);
    return this.evaluateRPN(rpn, angleMode);
  }

  // Format numerical result cleanly avoiding floating point glitches (like 0.1 + 0.2)
  public static formatResult(val: number, precision: number = -1): string {
    if (!isFinite(val)) {
      if (isNaN(val)) return 'Error';
      return val > 0 ? 'Infinity' : '-Infinity';
    }

    // Fix precision if specific precision requested
    if (precision > 0) {
      return parseFloat(val.toFixed(precision)).toString();
    }

    // Auto cleanup floating point drift
    const rounded = parseFloat(val.toPrecision(12));
    if (Math.abs(rounded) < 1e-12 && Math.abs(rounded) > 0) {
      return rounded.toExponential(4);
    }
    if (Math.abs(rounded) >= 1e14) {
      return rounded.toExponential(6);
    }
    return rounded.toString();
  }

  // Evaluate for graphing f(x)
  public static evaluateFunction(expr: string, xVal: number, angleMode: AngleMode = 'rad'): number {
    try {
      // Replace x with xVal safely
      const formattedX = `(${xVal})`;
      const replaced = expr.replace(/(^|[^a-zA-Z0-9])x([^a-zA-Z0-9]|$)/g, `$1${formattedX}$2`);
      return this.evaluate(replaced, angleMode);
    } catch {
      return NaN;
    }
  }
}
