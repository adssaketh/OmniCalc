import React, { useRef, useState, useEffect, useCallback } from 'react';
import { CalculatorMode } from '../types';
import { Calculator, Atom, ArrowLeftRight, BadgeDollarSign, LineChart, History } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface BottomNavBarProps {
  currentMode: CalculatorMode;
  onSelectMode: (mode: CalculatorMode) => void;
  soundEnabled: boolean;
  hapticEnabled: boolean;
  onOpenHistory: () => void;
  isHistoryOpen?: boolean;
  historyCount?: number;
  enableGrapher?: boolean;
}

interface NavSection {
  id: CalculatorMode | 'recents';
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  isRecents?: boolean;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  currentMode,
  onSelectMode,
  soundEnabled,
  hapticEnabled,
  onOpenHistory,
  isHistoryOpen = false,
  historyCount = 0,
  enableGrapher = false,
}) => {
  // Navigation sections list - Physics Lab next to Finance, Recents next to Finance
  const sections: NavSection[] = [
    { id: 'standard', label: 'Calculator', icon: Calculator },
    { id: 'converter', label: 'Converter', icon: ArrowLeftRight },
    { id: 'physics', label: 'Physics Lab', icon: Atom },
    { id: 'finance', label: 'Finance', icon: BadgeDollarSign },
    { id: 'recents', label: 'Recents', icon: History, isRecents: true },
  ];

  if (enableGrapher) {
    sections.push({ id: 'grapher', label: 'Grapher', icon: LineChart });
  }

  // Active section index
  const activeIndex = sections.findIndex((section) => {
    if (section.isRecents) return isHistoryOpen;
    return (
      !isHistoryOpen &&
      (currentMode === section.id || (currentMode === 'scientific' && section.id === 'standard'))
    );
  });
  const safeActiveIndex = activeIndex >= 0 ? activeIndex : 0;

  const dockRef = useRef<HTMLDivElement | null>(null);
  const iconWrapperRefs = useRef<Map<number, HTMLDivElement>>(new Map());

  // Dragging state
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragPillX, setDragPillX] = useState<number | null>(null);
  const isPointerDownRef = useRef<boolean>(false);
  const lastActiveIndexRef = useRef<number>(safeActiveIndex);
  const rafIdRef = useRef<number | null>(null);

  useEffect(() => {
    lastActiveIndexRef.current = safeActiveIndex;
  }, [safeActiveIndex]);

  // Pill layout geometry (centered exclusively on the icon)
  const [pillGeometry, setPillGeometry] = useState<{
    width: number;
    height: number;
    top: number;
    left: number;
  }>({ width: 56, height: 32, top: 8, left: 0 });

  const calculateIconPosition = useCallback((index: number) => {
    const iconEl = iconWrapperRefs.current.get(index);
    const dockEl = dockRef.current;
    if (iconEl && dockEl) {
      const iconRect = iconEl.getBoundingClientRect();
      const dockRect = dockEl.getBoundingClientRect();
      return {
        width: iconRect.width,
        height: iconRect.height,
        left: iconRect.left - dockRect.left,
        top: iconRect.top - dockRect.top,
      };
    }
    return null;
  }, []);

  const updatePillToActive = useCallback(() => {
    const pos = calculateIconPosition(safeActiveIndex);
    if (pos) {
      setPillGeometry(pos);
    }
  }, [safeActiveIndex, calculateIconPosition]);

  useEffect(() => {
    updatePillToActive();
    window.addEventListener('resize', updatePillToActive);
    return () => window.removeEventListener('resize', updatePillToActive);
  }, [updatePillToActive]);

  const selectSectionByIndex = useCallback(
    (index: number) => {
      const targetSection = sections[index];
      if (!targetSection) return;

      if (targetSection.isRecents) {
        if (!isHistoryOpen) {
          if (soundEnabled) soundFx.playClick('toggle');
          if (hapticEnabled) soundFx.triggerHaptic();
          onOpenHistory();
        }
      } else {
        if (currentMode !== targetSection.id || isHistoryOpen) {
          if (soundEnabled) soundFx.playClick('toggle');
          if (hapticEnabled) soundFx.triggerHaptic();
          onSelectMode(targetSection.id as CalculatorMode);
        }
      }
    },
    [sections, isHistoryOpen, currentMode, soundEnabled, hapticEnabled, onOpenHistory, onSelectMode]
  );

  // Pointer drag event handlers for the nav pill
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    isPointerDownRef.current = true;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);

    const dockEl = dockRef.current;
    if (!dockEl) return;
    const dockRect = dockEl.getBoundingClientRect();
    const relativeX = e.clientX - dockRect.left;

    setIsDragging(true);
    setDragPillX(relativeX - pillGeometry.width / 2);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isPointerDownRef.current || !dockRef.current) return;

    const dockRect = dockRef.current.getBoundingClientRect();
    const relativeX = e.clientX - dockRect.left;

    // Follow finger continuously
    const halfWidth = pillGeometry.width / 2;
    const clampedX = Math.max(0, Math.min(dockRect.width - pillGeometry.width, relativeX - halfWidth));

    if (rafIdRef.current) cancelAnimationFrame(rafIdRef.current);
    rafIdRef.current = requestAnimationFrame(() => {
      setDragPillX(clampedX);
    });

    // Determine nearest section by icon center
    let closestIndex = safeActiveIndex;
    let minDistance = Infinity;

    for (let i = 0; i < sections.length; i++) {
      const iconEl = iconWrapperRefs.current.get(i);
      if (iconEl) {
        const iconRect = iconEl.getBoundingClientRect();
        const iconCenterX = iconRect.left - dockRect.left + iconRect.width / 2;
        const dist = Math.abs(relativeX - iconCenterX);
        if (dist < minDistance) {
          minDistance = dist;
          closestIndex = i;
        }
      }
    }

    // Live screen change as pill crosses each section
    if (closestIndex !== lastActiveIndexRef.current) {
      lastActiveIndexRef.current = closestIndex;
      selectSectionByIndex(closestIndex);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isPointerDownRef.current) return;
    isPointerDownRef.current = false;

    if (rafIdRef.current) {
      cancelAnimationFrame(rafIdRef.current);
      rafIdRef.current = null;
    }

    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }

    setIsDragging(false);
    setDragPillX(null);
    updatePillToActive();
  };

  const handleButtonClick = (index: number) => {
    selectSectionByIndex(index);
  };

  // Determine current pill left position
  const currentPillLeft = isDragging && dragPillX !== null ? dragPillX : pillGeometry.left;

  return (
    <nav
      aria-label="Material 3 Expressive Navigation"
      className="fixed bottom-0 left-0 right-0 z-40 select-none transition-colors"
      style={{
        paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 8px)',
      }}
    >
      {/* M3 Expressive Floating Dock container with tonal surface */}
      <div className="max-w-xl sm:max-w-2xl mx-auto px-2 sm:px-4">
        <div
          ref={dockRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="relative rounded-[28px] sm:rounded-full px-2 py-2 flex items-center justify-around backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.5)] border border-white/10 touch-none cursor-pointer"
          style={{
            backgroundColor: 'color-mix(in srgb, var(--m3-surface-container) 92%, transparent)',
          }}
        >
          {/* M3 Expressive Fluid Moving Pill Indicator (Centered strictly over the Icon) */}
          <div
            className={`absolute pointer-events-none z-0 rounded-full ${
              isDragging ? '' : 'transition-all duration-300 ease-[cubic-bezier(0.34,1.4,0.64,1)]'
            }`}
            style={{
              top: `${pillGeometry.top}px`,
              left: `${currentPillLeft}px`,
              width: `${pillGeometry.width}px`,
              height: `${pillGeometry.height}px`,
              backgroundColor: 'var(--m3-primary-container)',
              transform: isDragging ? 'scale(1.08)' : 'scale(1)',
              boxShadow: isDragging
                ? '0 0 22px 3px var(--m3-primary), 0 4px 14px rgba(0,0,0,0.4)'
                : '0 2px 10px color-mix(in srgb, var(--m3-primary) 25%, transparent)',
              transition: isDragging
                ? 'transform 180ms cubic-bezier(0.2,0.9,0.2,1), box-shadow 180ms ease'
                : 'left 300ms cubic-bezier(0.34,1.4,0.64,1), top 300ms ease, width 300ms ease, height 300ms ease, transform 200ms ease, box-shadow 200ms ease',
              willChange: 'left, transform, box-shadow',
            }}
          />

          {sections.map((section, idx) => {
            const Icon = section.icon;
            const isActive = section.isRecents
              ? isHistoryOpen
              : !isHistoryOpen &&
                (currentMode === section.id || (currentMode === 'scientific' && section.id === 'standard'));

            return (
              <button
                key={section.id}
                onClick={() => handleButtonClick(idx)}
                className="group flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-2xl outline-none active:scale-95 relative z-10 cursor-pointer"
                title={section.isRecents ? `Recent Calculations (${historyCount})` : section.label}
              >
                {/* M3 Expressive Icon Pill Wrapper (Target for Centered Pill) */}
                <div
                  ref={(el) => {
                    if (el) iconWrapperRefs.current.set(idx, el);
                    else iconWrapperRefs.current.delete(idx);
                  }}
                  className="w-12 sm:w-16 h-8 rounded-full flex items-center justify-center relative transition-all duration-200"
                  style={{
                    color: isActive
                      ? 'var(--m3-on-primary-container)'
                      : 'var(--m3-on-surface-variant)',
                  }}
                >
                  <Icon
                    className={`w-4 h-4 sm:w-5 sm:h-5 transition-transform duration-250 ease-out ${
                      isActive
                        ? 'scale-110 drop-shadow-xs'
                        : 'opacity-70 group-hover:opacity-100 group-hover:scale-105'
                    }`}
                  />

                  {/* Recents counter badge */}
                  {section.isRecents && historyCount > 0 && (
                    <span
                      className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full text-[9px] font-bold flex items-center justify-center leading-none border border-black/30 shadow-xs"
                      style={{
                        backgroundColor: 'var(--m3-primary)',
                        color: 'var(--m3-on-primary)',
                      }}
                    >
                      {historyCount > 99 ? '99+' : historyCount}
                    </span>
                  )}
                </div>

                {/* M3 Expressive Typography Label - Positioned below pill, outside it */}
                <span
                  className={`text-[10px] sm:text-[11px] tracking-tight mt-1 leading-tight truncate max-w-[68px] sm:max-w-none text-center transition-all duration-200 ${
                    isActive
                      ? 'font-bold scale-102'
                      : 'font-medium opacity-80 group-hover:opacity-100'
                  }`}
                  style={{
                    color: isActive ? 'var(--m3-primary)' : 'var(--m3-on-surface-variant)',
                  }}
                >
                  {section.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
