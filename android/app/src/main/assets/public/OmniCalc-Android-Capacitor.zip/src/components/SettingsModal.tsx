import React from 'react';
import { AppSettings, ThemeId, AngleMode } from '../types';
import {
  X,
  Volume2,
  Smartphone,
  Compass,
  Hash,
  Palette,
  Check,
  LineChart,
  ShieldCheck,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Lock,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { OmniCalcLogo } from './OmniCalcLogo';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [showPrivacyPolicy, setShowPrivacyPolicy] = React.useState(false);
  if (!isOpen) return null;

  const themes: { id: ThemeId; name: string; desc: string; primary: string; secondary: string }[] = [
    {
      id: 'm3-iris',
      name: 'Expressive Iris',
      desc: 'Android 15 Flagship Monet',
      primary: '#a8c7fa',
      secondary: '#264585',
    },
    {
      id: 'm3-ocean',
      name: 'Dynamic Oceanic',
      desc: 'Teal & Deep Blue',
      primary: '#7bd0ff',
      secondary: '#004d67',
    },
    {
      id: 'm3-forest',
      name: 'Botanical Sage',
      desc: 'Forest & Mint Green',
      primary: '#9cd67d',
      secondary: '#23520e',
    },
    {
      id: 'm3-sunset',
      name: 'Sunset Terracotta',
      desc: 'Warm Coral & Amber',
      primary: '#ffb59d',
      secondary: '#72351f',
    },
    {
      id: 'm3-amoled',
      name: 'AMOLED Midnight',
      desc: 'Pitch Black & High Contrast',
      primary: '#c2c1ff',
      secondary: '#222228',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center sm:items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg rounded-[32px] sm:rounded-[36px] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[90vh] transition-all"
        style={{
          backgroundColor: 'var(--m3-surface-container-low)',
          color: 'var(--m3-on-surface)',
        }}
      >
        {/* M3 Expressive Drag Pill Handle */}
        <div className="pt-3 pb-1 flex justify-center">
          <div className="w-10 h-1 rounded-full opacity-40" style={{ backgroundColor: 'var(--m3-outline)' }} />
        </div>

        {/* Header */}
        <div className="px-6 py-3 flex items-center justify-between border-b border-white/5">
          <div className="flex flex-col">
            <h3 className="font-bold text-lg leading-tight" style={{ color: 'var(--m3-on-surface)' }}>
              Settings & Themes
            </h3>
            <span className="text-xs opacity-70" style={{ color: 'var(--m3-on-surface-variant)' }}>
              Material 3 Expressive System
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center transition-all active:scale-90 border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface-variant)',
            }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-6 space-y-5 text-sm overflow-y-auto">
          {/* M3 Audio Feedback Switch */}
          <div
            className="flex items-center justify-between p-3.5 rounded-[22px] border border-white/5"
            style={{ backgroundColor: 'var(--m3-surface-container)' }}
          >
            <div className="flex items-center gap-3.5">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-primary)',
                }}
              >
                <Volume2 className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-sm">Key Click Sounds</div>
                <div className="text-xs opacity-70" style={{ color: 'var(--m3-on-surface-variant)' }}>
                  Tactile mechanical audio responses
                </div>
              </div>
            </div>
            {/* M3 Expressive Toggle Switch */}
            <button
              onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
              className="w-14 h-8 rounded-full p-1 transition-all duration-200 flex items-center relative border border-white/5"
              style={{
                backgroundColor: settings.soundEnabled
                  ? 'var(--m3-primary)'
                  : 'var(--m3-surface-container-highest)',
              }}
            >
              <div
                className={`w-6 h-6 rounded-full shadow-md flex items-center justify-center transform transition-transform duration-200 ${
                  settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
                style={{
                  backgroundColor: settings.soundEnabled
                    ? 'var(--m3-on-primary)'
                    : 'var(--m3-outline)',
                }}
              >
                {settings.soundEnabled && <Check className="w-3.5 h-3.5 text-[var(--m3-primary)]" />}
              </div>
            </button>
          </div>

          {/* M3 Haptic Vibration Switch */}
          <div
            className="flex items-center justify-between p-3.5 rounded-[22px] border border-white/5"
            style={{ backgroundColor: 'var(--m3-surface-container)' }}
          >
            <div className="flex items-center gap-3.5">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-primary)',
                }}
              >
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-sm">Haptic Micro-Vibrations</div>
                <div className="text-xs opacity-70" style={{ color: 'var(--m3-on-surface-variant)' }}>
                  Haptic pulses on touch screen presses
                </div>
              </div>
            </div>
            {/* M3 Expressive Toggle Switch */}
            <button
              onClick={() => onUpdateSettings({ hapticEnabled: !settings.hapticEnabled })}
              className="w-14 h-8 rounded-full p-1 transition-all duration-200 flex items-center relative border border-white/5"
              style={{
                backgroundColor: settings.hapticEnabled
                  ? 'var(--m3-primary)'
                  : 'var(--m3-surface-container-highest)',
              }}
            >
              <div
                className={`w-6 h-6 rounded-full shadow-md flex items-center justify-center transform transition-transform duration-200 ${
                  settings.hapticEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
                style={{
                  backgroundColor: settings.hapticEnabled
                    ? 'var(--m3-on-primary)'
                    : 'var(--m3-outline)',
                }}
              >
                {settings.hapticEnabled && <Check className="w-3.5 h-3.5 text-[var(--m3-primary)]" />}
              </div>
            </button>
          </div>

          {/* Angle Mode Segmented Buttons */}
          <div
            className="flex items-center justify-between p-3.5 rounded-[22px] border border-white/5"
            style={{ backgroundColor: 'var(--m3-surface-container)' }}
          >
            <div className="flex items-center gap-3.5">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-primary)',
                }}
              >
                <Compass className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-sm">Angle Mode</div>
                <div className="text-xs opacity-70" style={{ color: 'var(--m3-on-surface-variant)' }}>
                  Trigonometric units
                </div>
              </div>
            </div>
            {/* Connected Segmented Pill */}
            <div
              className="flex items-center p-1 rounded-full border border-white/5"
              style={{ backgroundColor: 'var(--m3-surface-container-high)' }}
            >
              {(['deg', 'rad'] as AngleMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => onUpdateSettings({ angleMode: mode })}
                  className="px-3.5 py-1 text-xs font-semibold rounded-full transition-all duration-150"
                  style={{
                    backgroundColor:
                      settings.angleMode === mode ? 'var(--m3-primary)' : 'transparent',
                    color:
                      settings.angleMode === mode
                        ? 'var(--m3-on-primary)'
                        : 'var(--m3-on-surface-variant)',
                  }}
                >
                  {mode.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* Decimal Precision */}
          <div
            className="flex items-center justify-between p-3.5 rounded-[22px] border border-white/5"
            style={{ backgroundColor: 'var(--m3-surface-container)' }}
          >
            <div className="flex items-center gap-3.5">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-primary)',
                }}
              >
                <Hash className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-sm">Decimal Rounding</div>
                <div className="text-xs opacity-70" style={{ color: 'var(--m3-on-surface-variant)' }}>
                  Number precision
                </div>
              </div>
            </div>
            <select
              value={settings.decimalPrecision}
              onChange={(e) => onUpdateSettings({ decimalPrecision: parseInt(e.target.value) })}
              className="border border-white/10 text-xs rounded-full px-3 py-1.5 focus:outline-none font-mono cursor-pointer"
              style={{
                backgroundColor: 'var(--m3-surface-container-high)',
                color: 'var(--m3-on-surface)',
              }}
            >
              <option value="-1">Auto (Standard)</option>
              <option value="2">2 Decimals</option>
              <option value="4">4 Decimals</option>
              <option value="6">6 Decimals</option>
              <option value="8">8 Decimals</option>
            </select>
          </div>

          {/* Grapher Screen Toggle (Turn On or Off Completely) */}
          <div
            className="flex items-center justify-between p-3.5 rounded-[22px] border border-white/5"
            style={{ backgroundColor: 'var(--m3-surface-container)' }}
          >
            <div className="flex items-center gap-3.5">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-primary)',
                }}
              >
                <LineChart className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-sm">Grapher Screen</div>
                <div className="text-xs opacity-70" style={{ color: 'var(--m3-on-surface-variant)' }}>
                  {settings.enableGrapher ? 'Visible in bottom navigation bar' : 'Turned off & hidden completely'}
                </div>
              </div>
            </div>
            {/* M3 Expressive Toggle Switch */}
            <button
              onClick={() => onUpdateSettings({ enableGrapher: !settings.enableGrapher })}
              className="w-14 h-8 rounded-full p-1 transition-all duration-200 flex items-center relative border border-white/5 cursor-pointer"
              style={{
                backgroundColor: settings.enableGrapher
                  ? 'var(--m3-primary)'
                  : 'var(--m3-surface-container-highest)',
              }}
              title={settings.enableGrapher ? 'Grapher screen is turned ON' : 'Grapher screen is turned OFF'}
            >
              <div
                className={`w-6 h-6 rounded-full shadow-md flex items-center justify-center transform transition-transform duration-200 ${
                  settings.enableGrapher ? 'translate-x-6' : 'translate-x-0'
                }`}
                style={{
                  backgroundColor: settings.enableGrapher
                    ? 'var(--m3-on-primary)'
                    : 'var(--m3-outline)',
                }}
              >
                {settings.enableGrapher && <Check className="w-3.5 h-3.5 text-[var(--m3-primary)]" />}
              </div>
            </button>
          </div>

          {/* Material 3 Expressive Dynamic Theme Palettes */}
          <div className="pt-2">
            <div className="flex items-center gap-2 mb-3">
              <Palette className="w-4 h-4" style={{ color: 'var(--m3-primary)' }} />
              <div className="font-bold text-sm">Material 3 Expressive Color Themes</div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {themes.map((t) => {
                const isSelected = settings.theme === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => onUpdateSettings({ theme: t.id })}
                    className="p-3 rounded-[20px] text-left border transition-all duration-150 flex items-center gap-3 relative group active:scale-98"
                    style={{
                      backgroundColor: isSelected
                        ? 'var(--m3-surface-container-high)'
                        : 'var(--m3-surface-container)',
                      borderColor: isSelected ? 'var(--m3-primary)' : 'rgba(255,255,255,0.06)',
                    }}
                  >
                    {/* Dynamic Theme Logo Preview */}
                    <OmniCalcLogo theme={t.id} className="w-6 h-6 shrink-0 drop-shadow-xs" />

                    <div className="flex flex-col min-w-0 flex-1">
                      <span className="text-xs font-semibold leading-tight truncate">{t.name}</span>
                      <span className="text-[10px] opacity-60 leading-tight truncate">{t.desc}</span>
                    </div>

                    {isSelected && (
                      <span
                        className="w-5 h-5 rounded-full flex items-center justify-center shrink-0"
                        style={{
                          backgroundColor: 'var(--m3-primary)',
                          color: 'var(--m3-on-primary)',
                        }}
                      >
                        <Check className="w-3 h-3" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Privacy Policy & PWA Section */}
          <div className="pt-2 space-y-3">
            {/* Privacy Policy Card */}
            <div
              className="p-4 rounded-[24px] border border-white/5 flex flex-col gap-3 transition-colors"
              style={{ backgroundColor: 'var(--m3-surface-container)' }}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center shrink-0"
                    style={{
                      backgroundColor: 'var(--m3-primary-container)',
                      color: 'var(--m3-on-primary-container)',
                    }}
                  >
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold text-xs flex items-center gap-1.5 flex-wrap">
                      <span>Privacy Policy</span>
                      <span
                        className="px-1.5 py-0.5 rounded-full text-[9px] font-bold"
                        style={{
                          backgroundColor: 'var(--m3-primary)',
                          color: 'var(--m3-on-primary)',
                        }}
                      >
                        100% On-Device
                      </span>
                    </div>
                    <div
                      className="text-[11px] opacity-70 truncate"
                      style={{ color: 'var(--m3-on-surface-variant)' }}
                    >
                      Zero data collection • Local storage only
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => setShowPrivacyPolicy(!showPrivacyPolicy)}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-full transition-all active:scale-95 border border-white/10 flex items-center gap-1"
                    style={{
                      backgroundColor: 'var(--m3-surface-container-high)',
                      color: 'var(--m3-primary)',
                    }}
                  >
                    <span>{showPrivacyPolicy ? 'Hide' : 'Read'}</span>
                    {showPrivacyPolicy ? (
                      <ChevronUp className="w-3 h-3" />
                    ) : (
                      <ChevronDown className="w-3 h-3" />
                    )}
                  </button>
                  <a
                    href="/privacy-policy.html"
                    target="_blank"
                    rel="noopener noreferrer"
                    title="Open standalone Privacy Policy page"
                    className="p-1 rounded-full opacity-70 hover:opacity-100 transition-opacity"
                    style={{ color: 'var(--m3-primary)' }}
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* In-App Expandable Privacy Policy Content */}
              {showPrivacyPolicy && (
                <div
                  className="p-3.5 rounded-[18px] text-xs space-y-2.5 border border-white/5 animate-in fade-in duration-200"
                  style={{ backgroundColor: 'var(--m3-surface-container-low)' }}
                >
                  <div className="flex items-center justify-between pb-1.5 border-b border-white/5">
                    <span className="font-bold text-[11px] flex items-center gap-1.5" style={{ color: 'var(--m3-primary)' }}>
                      <Lock className="w-3 h-3" />
                      OmniCalc By Saketh Privacy Commitment
                    </span>
                    <span className="text-[10px] opacity-60">Effective Oct 2026</span>
                  </div>

                  <div className="space-y-2 text-[11px] leading-relaxed opacity-90">
                    <div className="flex items-start gap-2">
                      <span className="font-semibold text-emerald-400 shrink-0">•</span>
                      <div>
                        <strong>Zero Data Collection:</strong> We do not collect, transmit, sell, or profile any personally identifiable information (PII) or telemetry. No account or login is required.
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <span className="font-semibold text-emerald-400 shrink-0">•</span>
                      <div>
                        <strong>On-Device Storage:</strong> All calculation history, angle settings, grapher preferences, and financial SIP values are stored exclusively in your device's local storage. You can delete all history anytime with "Clear All".
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <span className="font-semibold text-emerald-400 shrink-0">•</span>
                      <div>
                        <strong>No Third-Party Trackers:</strong> No advertising SDKs, behavioral analytics, or third-party cookies are included in this app.
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <span className="font-semibold text-emerald-400 shrink-0">•</span>
                      <div>
                        <strong>Device Permissions:</strong> Sound feedback uses procedural client-side Web Audio oscillators. No microphone, camera, contacts, or location access is requested.
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <span className="font-semibold text-emerald-400 shrink-0">•</span>
                      <div>
                        <strong>Children & Families Safe:</strong> Fully compliant with COPPA and Google Play Developer Program policies for all ages.
                      </div>
                    </div>

                    <div className="pt-2 border-t border-white/5 flex flex-wrap items-center justify-between gap-2 text-[10px]">
                      <span className="opacity-70">
                        Contact: <strong className="font-medium">saketh.adhikarla@gmail.com</strong>
                      </span>
                      <a
                        href="/privacy-policy.html"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-semibold underline flex items-center gap-1"
                        style={{ color: 'var(--m3-primary)' }}
                      >
                        <span>Full Web Policy</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Progressive Web App Direct Install */}
            <div
              className="p-4 rounded-[24px] border border-white/5 flex flex-col gap-2.5"
              style={{ backgroundColor: 'var(--m3-surface-container)' }}
            >
              <div>
                <div className="font-semibold text-xs">Progressive Web App</div>
                <div className="text-[11px] opacity-70" style={{ color: 'var(--m3-on-surface-variant)' }}>
                  Install OmniCalc By Saketh as a standalone home-screen app
                </div>
              </div>
              <PWAInstallButton variant="button" />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-white/5 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold rounded-full transition-all active:scale-95 shadow-sm"
            style={{
              backgroundColor: 'var(--m3-primary)',
              color: 'var(--m3-on-primary)',
            }}
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
