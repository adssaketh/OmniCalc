import React, { useState } from 'react';
import { UNIT_CATEGORIES, convertUnit } from '../engine/units';
import { soundFx } from '../utils/audio';
import { ArrowLeftRight, Copy, Check, RotateCcw } from 'lucide-react';
import { SwipeableTabContainer, TabItem } from './SwipeableTabContainer';

interface ConverterScreenProps {
  soundEnabled: boolean;
  hapticEnabled: boolean;
  decimalPrecision: number;
}

export const ConverterScreen: React.FC<ConverterScreenProps> = ({
  soundEnabled,
  hapticEnabled,
  decimalPrecision,
}) => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('length');
  const activeCategory = UNIT_CATEGORIES.find((c) => c.id === selectedCategoryId) || UNIT_CATEGORIES[0];

  const [fromUnitId, setFromUnitId] = useState<string>(activeCategory.units[0].id);
  const [toUnitId, setToUnitId] = useState<string>(activeCategory.units[1]?.id || activeCategory.units[0].id);
  const [inputValue, setInputValue] = useState<string>('1');
  const [copied, setCopied] = useState<boolean>(false);
  const [isSwapping, setIsSwapping] = useState<boolean>(false);

  // Audio helper
  const playSound = (type: 'num' | 'op' | 'eval' | 'clear' | 'toggle' = 'num') => {
    if (soundEnabled) soundFx.playClick(type);
    if (hapticEnabled) soundFx.triggerHaptic();
  };

  // Change category safely
  const handleSelectCategory = (catId: string) => {
    playSound('toggle');
    setSelectedCategoryId(catId);
    const cat = UNIT_CATEGORIES.find((c) => c.id === catId) || UNIT_CATEGORIES[0];
    setFromUnitId(cat.units[0].id);
    setToUnitId(cat.units[1]?.id || cat.units[0].id);
    setInputValue('1');
  };

  // Swap From & To with 180deg animation
  const handleSwap = () => {
    playSound('op');
    setIsSwapping(true);
    const oldFrom = fromUnitId;
    setFromUnitId(toUnitId);
    setToUnitId(oldFrom);
    setTimeout(() => setIsSwapping(false), 300);
  };

  const parsedVal = parseFloat(inputValue);
  const conversion = convertUnit(
    isNaN(parsedVal) ? 0 : parsedVal,
    activeCategory,
    fromUnitId,
    toUnitId
  );

  const formattedResult = !isNaN(parsedVal)
    ? decimalPrecision > 0
      ? conversion.result.toFixed(decimalPrecision)
      : parseFloat(conversion.result.toPrecision(8)).toString()
    : '0';

  const handleCopy = () => {
    playSound('op');
    navigator.clipboard.writeText(formattedResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const presets = [1, 5, 10, 50, 100];

  const categoryTabs: TabItem[] = UNIT_CATEGORIES.map((c) => ({
    id: c.id,
    label: c.name,
  }));

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col items-center">
      <SwipeableTabContainer
        tabs={categoryTabs}
        activeTabId={selectedCategoryId}
        onSelectTab={handleSelectCategory}
      >
        {/* Main Conversion Surface */}
        <div
          className="w-full rounded-[32px] sm:rounded-[36px] shadow-2xl p-4 sm:p-7 backdrop-blur-xl border border-white/10 transition-all duration-300"
          style={{
            backgroundColor: 'color-mix(in srgb, var(--m3-surface-container-low) 96%, transparent)',
          }}
        >
          <div className="grid grid-cols-1 md:grid-cols-[1fr,auto,1fr] gap-3.5 sm:gap-6 items-center">
            {/* FROM PANEL */}
            <div
              className="rounded-[24px] sm:rounded-[28px] p-4 sm:p-5 flex flex-col gap-3 border border-white/5 transition-all duration-200"
              style={{ backgroundColor: 'var(--m3-surface-container)' }}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-400">From</span>
                <select
                  value={fromUnitId}
                  onChange={(e) => {
                    playSound('toggle');
                    setFromUnitId(e.target.value);
                  }}
                  className="bg-neutral-900 border border-white/15 text-xs font-medium text-neutral-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-[var(--m3-primary)] max-w-[160px] cursor-pointer"
                >
                  {activeCategory.units.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.symbol})
                    </option>
                  ))}
                </select>
              </div>

              <div className="relative mt-2">
                <input
                  type="number"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="0"
                  className="w-full bg-transparent text-2xl sm:text-3xl font-mono font-bold text-white focus:outline-none tracking-tight pr-8"
                />
                {inputValue && (
                  <button
                    onClick={() => {
                      playSound('clear');
                      setInputValue('');
                    }}
                    className="absolute right-0 top-1/2 -translate-y-1/2 p-1 text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer active:scale-90"
                    title="Clear input"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="text-xs text-neutral-500 font-mono">
                Unit: {activeCategory.units.find((u) => u.id === fromUnitId)?.symbol}
              </div>
            </div>

            {/* SWAP BUTTON */}
            <div className="flex justify-center -my-2 md:my-0">
              <button
                onClick={handleSwap}
                className="w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 active:scale-90 shadow-md border border-white/5 cursor-pointer"
                style={{
                  backgroundColor: 'var(--m3-secondary-container)',
                  color: 'var(--m3-on-secondary-container)',
                  transform: isSwapping ? 'rotate(180deg) scale(0.92)' : 'rotate(0deg) scale(1)',
                }}
                title="Swap units"
              >
                <ArrowLeftRight className="w-5 h-5 transition-transform" />
              </button>
            </div>

            {/* TO PANEL */}
            <div
              className="rounded-[24px] sm:rounded-[28px] p-4 sm:p-5 flex flex-col gap-3 border border-white/5 transition-all duration-200"
              style={{ backgroundColor: 'var(--m3-surface-container)' }}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-400">To</span>
                <select
                  value={toUnitId}
                  onChange={(e) => {
                    playSound('toggle');
                    setToUnitId(e.target.value);
                  }}
                  className="bg-neutral-900 border border-white/15 text-xs font-medium text-neutral-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-[var(--m3-primary)] max-w-[160px] cursor-pointer"
                >
                  {activeCategory.units.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.symbol})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-between mt-2 min-h-[44px]">
                <span
                  key={formattedResult}
                  className="text-2xl sm:text-3xl font-mono font-bold select-all overflow-x-auto whitespace-nowrap scrollbar-none tracking-tight animate-m3-result-update"
                  style={{ color: 'var(--m3-primary)' }}
                >
                  {formattedResult}
                </span>
                <button
                  onClick={handleCopy}
                  className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/[0.08] transition-all duration-150 active:scale-90 shrink-0 ml-2 cursor-pointer"
                  title="Copy converted value"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-emerald-400 animate-in zoom-in-75 duration-150" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>

              <div className="text-xs text-neutral-500 font-mono">
                Unit: {activeCategory.units.find((u) => u.id === toUnitId)?.symbol}
              </div>
            </div>
          </div>

          {/* Quick Value Presets Bar */}
          <div className="mt-6 pt-5 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-neutral-400">Presets:</span>
              <div className="flex items-center gap-1.5">
                {presets.map((p) => (
                  <button
                    key={p}
                    onClick={() => {
                      playSound('num');
                      setInputValue(p.toString());
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition-all duration-150 active:scale-90 cursor-pointer ${
                      inputValue === p.toString()
                        ? 'bg-[var(--m3-primary-container)] text-[var(--m3-on-primary-container)] border border-[var(--m3-primary)]/40 shadow-xs'
                        : 'bg-white/[0.04] text-neutral-400 hover:text-white hover:bg-white/[0.08]'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Formula relation info */}
            {conversion.formula && (
              <div className="text-xs font-mono text-neutral-400 bg-white/[0.03] px-3 py-1.5 rounded-lg border border-white/5 transition-all">
                {conversion.formula}
              </div>
            )}
          </div>
        </div>
      </SwipeableTabContainer>
    </div>
  );
};
