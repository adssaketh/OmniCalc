import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Check, Share2, PlusSquare, Smartphone, Monitor, X, ExternalLink } from 'lucide-react';
import { OmniCalcLogo } from './OmniCalcLogo';

interface PWAInstallButtonProps {
  variant?: 'header' | 'button' | 'banner';
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'header',
  className = '',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState<boolean>(false);
  const [justInstalled, setJustInstalled] = useState<boolean>(false);

  // If already running in standalone PWA mode
  if (isInstalled) {
    if (variant === 'header') {
      return (
        <span
          title="App is running as installed PWA"
          className="hidden sm:inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
        >
          <Check className="w-3 h-3" />
          <span>App Installed</span>
        </span>
      );
    }
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        setJustInstalled(true);
        setTimeout(() => setJustInstalled(false), 3000);
      }
    } else {
      // Show guided instructions modal for the browser / device
      setShowGuide(true);
    }
  };

  return (
    <>
      {variant === 'header' && (
        <button
          onClick={handleInstallClick}
          aria-label="Install OmniCalc as PWA"
          title="Install OmniCalc on your device for offline use"
          className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-lg transition-all shadow-sm ${
            isInstallable
              ? 'bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white shadow-emerald-500/20'
              : 'bg-white/[0.08] hover:bg-white/[0.12] text-neutral-200 border border-white/10'
          } ${className}`}
        >
          {justInstalled ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-300" />
              <span className="hidden sm:inline">Installed!</span>
            </>
          ) : (
            <>
              <Download className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
              <span className="whitespace-nowrap">Install App</span>
            </>
          )}
        </button>
      )}

      {variant === 'banner' && (
        <div className={`w-full bg-gradient-to-r from-slate-900 via-neutral-900 to-slate-900 border border-emerald-500/30 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs ${className}`}>
          <div className="flex items-center gap-2.5">
            <OmniCalcLogo className="w-9 h-9 drop-shadow-md" />
            <div>
              <div className="font-semibold text-white">Install OmniCalc</div>
              <div className="text-neutral-400 text-[11px]">
                Add to your home screen or desktop with adaptive icon and 1-tap offline access
              </div>
            </div>
          </div>
          <button
            onClick={handleInstallClick}
            className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 shrink-0 shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Install Now</span>
          </button>
        </div>
      )}

      {variant === 'button' && (
        <button
          onClick={handleInstallClick}
          className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md transition-all ${className}`}
        >
          <Download className="w-4 h-4" />
          <span>Install OmniCalc App</span>
        </button>
      )}

      {/* Guided Installation Modal */}
      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="w-full max-w-md bg-neutral-900 border border-white/15 rounded-2xl p-5 sm:p-6 shadow-2xl relative text-left"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowGuide(false)}
              className="absolute right-4 top-4 p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <OmniCalcLogo className="w-11 h-11 drop-shadow-lg" />
              <div>
                <h3 className="text-base font-bold text-white">Install OmniCalc</h3>
                <p className="text-xs text-neutral-400">Adaptive icon automatically matches your device shape</p>
              </div>
            </div>

            {isIOS ? (
              /* iOS Safari instructions */
              <div className="space-y-3 bg-neutral-950 p-4 rounded-xl border border-white/10 text-xs">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 font-bold text-[11px]">
                    1
                  </span>
                  <div>
                    Tap the <strong className="text-white">Share</strong> button (
                    <Share2 className="w-3.5 h-3.5 inline mx-1 text-indigo-400" />
                    ) at the bottom toolbar of Safari.
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 font-bold text-[11px]">
                    2
                  </span>
                  <div>
                    Scroll down and tap <strong className="text-white">Add to Home Screen</strong> (
                    <PlusSquare className="w-3.5 h-3.5 inline mx-1 text-indigo-400" />
                    ).
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 font-bold text-[11px]">
                    3
                  </span>
                  <div>
                    Tap <strong className="text-white">Add</strong> in top-right. OmniCalc is now installed on your home screen!
                  </div>
                </div>
              </div>
            ) : (
              /* Desktop / Android Chrome / Edge instructions */
              <div className="space-y-3.5 text-xs">
                <div className="bg-neutral-950 p-3.5 rounded-xl border border-white/10">
                  <div className="flex items-center gap-2 font-semibold text-neutral-200 mb-1.5">
                    <Monitor className="w-4 h-4 text-indigo-400" />
                    <span>Chrome / Edge / Brave on Desktop</span>
                  </div>
                  <p className="text-neutral-400 text-[11px] leading-relaxed">
                    Click the <strong className="text-white">Install</strong> icon (
                    <Download className="w-3 h-3 inline text-indigo-400 mx-0.5" />
                    ) in the browser address bar on the right side, or click <strong className="text-white">Settings (⋮) → Cast, save and share → Install OmniCalc</strong>.
                  </p>
                </div>

                <div className="bg-neutral-950 p-3.5 rounded-xl border border-white/10">
                  <div className="flex items-center gap-2 font-semibold text-neutral-200 mb-1.5">
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <span>Android / Chrome Mobile</span>
                  </div>
                  <p className="text-neutral-400 text-[11px] leading-relaxed">
                    Tap the browser menu <strong className="text-white">(⋮)</strong> at top right and choose <strong className="text-white">Install app</strong> or <strong className="text-white">Add to Home screen</strong>.
                  </p>
                </div>
              </div>
            )}

            <div className="mt-5 flex items-center justify-between gap-3 pt-3 border-t border-white/10 text-xs">
              <span className="text-[11px] text-neutral-400">Works 100% offline once installed</span>
              <button
                onClick={() => setShowGuide(false)}
                className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium transition-colors"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
