/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CalculatorMode, HistoryItem, AppSettings } from './types';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { Header } from './components/Header';
import { BottomNavBar } from './components/BottomNavBar';
import { CalculatorScreen } from './components/CalculatorScreen';
import { ConverterScreen } from './components/ConverterScreen';
import { FinanceScreen } from './components/FinanceScreen';
import { PhysicsScreen } from './components/PhysicsScreen';
import { GraphScreen } from './components/GraphScreen';
import { HistoryTapeModal } from './components/HistoryTapeModal';
import { SettingsModal } from './components/SettingsModal';

const DEFAULT_SETTINGS: AppSettings = {
  soundEnabled: true,
  hapticEnabled: true,
  angleMode: 'deg',
  decimalPrecision: -1,
  theme: 'm3-iris',
  currencySymbol: '₹',
  currencyCode: 'INR',
  enableGrapher: false,
};

export default function App() {
  const [currentMode, setCurrentMode] = useState<CalculatorMode>('standard');
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [externalExpression, setExternalExpression] = useState<string>('');

  // Persisted History
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('omni_calc_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Persisted Settings
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('omni_calc_settings');
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Save history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('omni_calc_history', JSON.stringify(history));
    } catch {
      // storage full or blocked
    }
  }, [history]);

  // Save settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('omni_calc_settings', JSON.stringify(settings));
    } catch {
      // ignore
    }
  }, [settings]);

  // Add calculation to history tape
  const handleAddHistory = (item: Omit<HistoryItem, 'id' | 'timestamp'>) => {
    const newItem: HistoryItem = {
      ...item,
      id: Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
    };
    setHistory((prev) => [newItem, ...prev.slice(0, 99)]);
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  const handleSelectResult = (val: string) => {
    setExternalExpression(val);
    setCurrentMode('standard');
  };

  const handleUpdateSettings = (partial: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  // If grapher is turned off in settings, return to standard calculator
  useEffect(() => {
    if (!settings.enableGrapher && currentMode === 'grapher') {
      setCurrentMode('standard');
    }
  }, [settings.enableGrapher, currentMode]);

  // Theme styling wrapper
  const getM3ThemeDataAttr = (): string => {
    switch (settings.theme) {
      case 'm3-ocean':
        return 'oceanic';
      case 'm3-forest':
        return 'forest';
      case 'm3-sunset':
        return 'sunset';
      case 'm3-amoled':
      case 'oled-midnight':
        return 'amoled';
      case 'cyber-emerald':
        return 'forest';
      case 'm3-iris':
      case 'dark-obsidian':
      default:
        return 'iris';
    }
  };

  // Dynamically synchronize Android status bar theme-color and root document background
  useEffect(() => {
    const themeColors: Record<string, string> = {
      'm3-iris': '#111318',
      'm3-ocean': '#0e1417',
      'm3-forest': '#101510',
      'm3-sunset': '#171210',
      'm3-amoled': '#000000',
      'oled-midnight': '#000000',
      'cyber-emerald': '#101510',
      'dark-obsidian': '#111318',
    };
    const surfaceColor = themeColors[settings.theme] || '#111318';
    const dataAttr = getM3ThemeDataAttr();

    // 1. Set root HTML dataset and background colors
    document.documentElement.setAttribute('data-m3-theme', dataAttr);
    document.documentElement.style.backgroundColor = surfaceColor;
    document.documentElement.style.colorScheme = 'dark';
    document.body.style.backgroundColor = surfaceColor;

    // 2. Update Android system status bar meta tag dynamically
    let metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (!metaThemeColor) {
      metaThemeColor = document.createElement('meta');
      metaThemeColor.setAttribute('name', 'theme-color');
      document.head.appendChild(metaThemeColor);
    }
    metaThemeColor.setAttribute('content', surfaceColor);

    // 3. Synchronize native Android status bar in Capacitor
    if (Capacitor.isNativePlatform()) {
      StatusBar.setBackgroundColor({ color: surfaceColor }).catch(() => {});
      StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
    }
  }, [settings.theme]);

  // Android Native Back Button: dismiss modals first, then exit application
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    let listenerPromise = CapApp.addListener('backButton', () => {
      if (isSettingsOpen) {
        setIsSettingsOpen(false);
      } else if (isHistoryOpen) {
        setIsHistoryOpen(false);
      } else {
        CapApp.exitApp();
      }
    });

    return () => {
      listenerPromise.then((handle) => handle.remove()).catch(() => {});
    };
  }, [isSettingsOpen, isHistoryOpen]);

  return (
    <div
      data-m3-theme={getM3ThemeDataAttr()}
      className="min-h-screen flex flex-col font-sans transition-colors duration-300"
      style={{
        backgroundColor: 'var(--m3-surface)',
        color: 'var(--m3-on-surface)',
      }}
    >
      {/* Top Bar Header with brand, PWA install, sound, and settings */}
      <Header
        soundEnabled={settings.soundEnabled}
        onToggleSound={() => handleUpdateSettings({ soundEnabled: !settings.soundEnabled })}
        onOpenSettings={() => setIsSettingsOpen(true)}
        theme={settings.theme}
      />

      {/* Main Workspace Area with bottom padding for bottom navigation bar */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 py-2 sm:py-6 pb-24 sm:pb-28 flex flex-col justify-start">
        {/* Animated Screen Container */}
        <div key={currentMode} className="w-full flex-1 flex flex-col animate-m3-screen-enter">
          {currentMode === 'standard' && (
            <CalculatorScreen
              angleMode={settings.angleMode}
              onToggleAngleMode={() =>
                handleUpdateSettings({ angleMode: settings.angleMode === 'deg' ? 'rad' : 'deg' })
              }
              decimalPrecision={settings.decimalPrecision}
              soundEnabled={settings.soundEnabled}
              hapticEnabled={settings.hapticEnabled}
              onAddHistory={handleAddHistory}
              externalExpression={externalExpression}
              history={history}
              onOpenHistory={() => setIsHistoryOpen(true)}
              onSelectHistoryItem={(expr) => setExternalExpression(expr)}
            />
          )}

          {currentMode === 'converter' && (
            <ConverterScreen
              soundEnabled={settings.soundEnabled}
              hapticEnabled={settings.hapticEnabled}
              decimalPrecision={settings.decimalPrecision}
            />
          )}

          {currentMode === 'finance' && (
            <FinanceScreen
              soundEnabled={settings.soundEnabled}
              hapticEnabled={settings.hapticEnabled}
              currencySymbol={settings.currencySymbol || '₹'}
            />
          )}

          {currentMode === 'physics' && (
            <PhysicsScreen
              soundEnabled={settings.soundEnabled}
              hapticEnabled={settings.hapticEnabled}
              onInsertToCalculator={handleSelectResult}
            />
          )}

          {settings.enableGrapher && currentMode === 'grapher' && (
            <GraphScreen
              soundEnabled={settings.soundEnabled}
              hapticEnabled={settings.hapticEnabled}
            />
          )}
        </div>
      </main>

      {/* Persistent Bottom Navigation Dock with little symbols */}
      <BottomNavBar
        currentMode={currentMode}
        onSelectMode={(mode) => {
          setCurrentMode(mode);
          setExternalExpression('');
        }}
        soundEnabled={settings.soundEnabled}
        hapticEnabled={settings.hapticEnabled}
        onOpenHistory={() => setIsHistoryOpen(true)}
        isHistoryOpen={isHistoryOpen}
        historyCount={history.length}
        enableGrapher={settings.enableGrapher}
      />

      {/* History Tape Modal */}
      <HistoryTapeModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onSelectResult={handleSelectResult}
        onClearHistory={handleClearHistory}
      />

      {/* Settings & Preferences Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />
    </div>
  );
}
