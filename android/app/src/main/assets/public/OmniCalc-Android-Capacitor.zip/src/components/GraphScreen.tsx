import React, { useState, useRef, useEffect, useCallback } from 'react';
import { MathEvaluator } from '../engine/evaluator';
import { soundFx } from '../utils/audio';
import { ZoomIn, ZoomOut, RotateCcw, Crosshair } from 'lucide-react';

interface GraphScreenProps {
  soundEnabled: boolean;
  hapticEnabled: boolean;
}

export const GraphScreen: React.FC<GraphScreenProps> = ({
  soundEnabled,
  hapticEnabled,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [expression, setExpression] = useState<string>('sin(x) * 2');
  const [activeExpr, setActiveExpr] = useState<string>('sin(x) * 2');
  const [scale, setScale] = useState<number>(40); // pixels per unit
  const [origin, setOrigin] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [mouseCoord, setMouseCoord] = useState<{ x: number; y: number } | null>(null);

  const presets = [
    { label: 'sin(x)', expr: 'sin(x)' },
    { label: 'x² − 4', expr: 'x^2 - 4' },
    { label: 'cos(2x)', expr: 'cos(2*x)' },
    { label: 'x³ − 3x', expr: 'x^3 - 3*x' },
    { label: '|x| − 2', expr: 'abs(x) - 2' },
  ];

  const playSound = (type: 'num' | 'op' | 'toggle' = 'num') => {
    if (soundEnabled) soundFx.playClick(type);
    if (hapticEnabled) soundFx.triggerHaptic();
  };

  // Canvas drawing routine
  const drawGraph = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear background
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, width, height);

    const ox = width / 2 + origin.x;
    const oy = height / 2 + origin.y;

    // Draw Grid Lines
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.font = '10px "JetBrains Mono", monospace';

    // Step size based on scale
    const step = scale;

    // Vertical grid
    for (let x = ox % step; x < width; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();

      const unitVal = ((x - ox) / scale).toFixed(0);
      if (unitVal !== '0') {
        ctx.fillText(unitVal, x + 3, oy - 4);
      }
    }

    // Horizontal grid
    for (let y = oy % step; y < height; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();

      const unitVal = (-(y - oy) / scale).toFixed(0);
      if (unitVal !== '0') {
        ctx.fillText(unitVal, ox + 4, y - 3);
      }
    }

    // Primary Axes (X and Y)
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';

    // X Axis
    ctx.beginPath();
    ctx.moveTo(0, oy);
    ctx.lineTo(width, oy);
    ctx.stroke();

    // Y Axis
    ctx.beginPath();
    ctx.moveTo(ox, 0);
    ctx.lineTo(ox, height);
    ctx.stroke();

    // Plot Function Curve
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#6366f1'; // indigo-500
    ctx.beginPath();

    let isDrawing = false;

    // Plot across canvas width in 1-pixel increments
    for (let px = 0; px <= width; px += 2) {
      const mathX = (px - ox) / scale;
      const mathY = MathEvaluator.evaluateFunction(activeExpr, mathX, 'rad');

      if (!isNaN(mathY) && isFinite(mathY)) {
        const py = oy - mathY * scale;

        // Clip huge vertical spikes (e.g. near asymptotes)
        if (py >= -100 && py <= height + 100) {
          if (!isDrawing) {
            ctx.moveTo(px, py);
            isDrawing = true;
          } else {
            ctx.lineTo(px, py);
          }
        } else {
          isDrawing = false;
        }
      } else {
        isDrawing = false;
      }
    }
    ctx.stroke();

    // Crosshair for cursor if mouse over
    if (mouseCoord) {
      const mx = mouseCoord.x;
      const my = mouseCoord.y;
      const cursorX = (mx - ox) / scale;
      const cursorY = MathEvaluator.evaluateFunction(activeExpr, cursorX, 'rad');

      if (!isNaN(cursorY) && isFinite(cursorY)) {
        const targetPy = oy - cursorY * scale;

        // Point on curve
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.arc(mx, targetPy, 4.5, 0, Math.PI * 2);
        ctx.fill();

        // Cross lines
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(mx, 0);
        ctx.lineTo(mx, height);
        ctx.moveTo(0, targetPy);
        ctx.lineTo(width, targetPy);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }
  }, [activeExpr, origin, scale, mouseCoord]);

  // Handle Resize and Initial Draw
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      drawGraph();
    };

    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [drawGraph]);

  // Redraw when state updates
  useEffect(() => {
    drawGraph();
  }, [drawGraph]);

  // Mouse pan handlers
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - origin.x, y: e.clientY - origin.y });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setMouseCoord({ x, y });

    if (isDragging) {
      setOrigin({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Mobile Touch pan handlers
  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      setIsDragging(true);
      setDragStart({ x: touch.clientX - origin.x, y: touch.clientY - origin.y });
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const x = touch.clientX - rect.left;
      const y = touch.clientY - rect.top;
      setMouseCoord({ x, y });

      if (isDragging) {
        setOrigin({
          x: touch.clientX - dragStart.x,
          y: touch.clientY - dragStart.y,
        });
      }
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.85;
    setScale((s) => Math.min(250, Math.max(10, s * zoomFactor)));
  };

  const handlePlot = (e: React.FormEvent) => {
    e.preventDefault();
    playSound('op');
    setActiveExpr(expression);
  };

  const handleReset = () => {
    playSound('toggle');
    setScale(40);
    setOrigin({ x: 0, y: 0 });
  };

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col items-center select-none">
      <div
        className="w-full rounded-[32px] sm:rounded-[36px] shadow-2xl p-4 sm:p-7 backdrop-blur-xl flex flex-col gap-4 border border-white/10"
        style={{
          backgroundColor: 'color-mix(in srgb, var(--m3-surface-container-low) 96%, transparent)',
        }}
      >
        {/* Function Input Bar */}
        <form onSubmit={handlePlot} className="flex flex-col sm:flex-row items-center gap-2">
          <div className="relative flex-1 w-full">
            <span
              className="absolute left-4 top-1/2 -translate-y-1/2 text-sm font-mono opacity-70"
              style={{ color: 'var(--m3-outline)' }}
            >
              f(x) =
            </span>
            <input
              type="text"
              value={expression}
              onChange={(e) => setExpression(e.target.value)}
              placeholder="e.g. sin(x) * 2"
              className="w-full border border-white/10 rounded-full pl-16 pr-4 py-3 font-mono text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-[var(--m3-primary)] transition-all"
              style={{
                backgroundColor: 'var(--m3-surface-container-lowest)',
                color: 'var(--m3-on-surface)',
              }}
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="submit"
              className="flex-1 sm:flex-none px-6 py-3 rounded-full font-semibold text-xs transition-all shadow-md active:scale-95 whitespace-nowrap"
              style={{
                backgroundColor: 'var(--m3-primary)',
                color: 'var(--m3-on-primary)',
              }}
            >
              Plot Function
            </button>
            <button
              type="button"
              onClick={handleReset}
              className="w-11 h-11 rounded-full flex items-center justify-center border border-white/5 transition-all active:scale-90"
              style={{
                backgroundColor: 'var(--m3-surface-container)',
                color: 'var(--m3-on-surface-variant)',
              }}
              title="Reset View"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </form>

        {/* Quick Presets with M3 Expressive Pill Chips */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="opacity-70 mr-1 text-[11px]" style={{ color: 'var(--m3-outline)' }}>
            Presets:
          </span>
          {presets.map((p) => (
            <button
              key={p.label}
              onClick={() => {
                playSound('toggle');
                setExpression(p.expr);
                setActiveExpr(p.expr);
              }}
              className="px-3.5 py-1.5 rounded-full font-mono text-xs border border-white/5 transition-all active:scale-95"
              style={{
                backgroundColor: 'var(--m3-surface-container)',
                color: 'var(--m3-on-surface)',
              }}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Canvas Plotter Container */}
        <div className="relative w-full h-[360px] sm:h-[420px] rounded-[24px] overflow-hidden border border-white/10 bg-[#090d16] select-none">
          <canvas
            ref={canvasRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onMouseLeave={() => {
              handleMouseUp();
              setMouseCoord(null);
            }}
            onWheel={handleWheel}
            className="w-full h-full cursor-grab active:cursor-grabbing block touch-none"
          />

          {/* Floating Controls Overlay */}
          <div className="absolute bottom-3 right-3 flex items-center gap-1.5 p-1 rounded-xl bg-neutral-950/80 backdrop-blur border border-white/10">
            <button
              onClick={() => {
                playSound('toggle');
                setScale((s) => Math.min(250, s * 1.25));
              }}
              className="p-1.5 rounded-lg text-neutral-300 hover:text-white hover:bg-white/10 transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                playSound('toggle');
                setScale((s) => Math.max(10, s / 1.25));
              }}
              className="p-1.5 rounded-lg text-neutral-300 hover:text-white hover:bg-white/10 transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
          </div>

          {/* Coordinates Tooltip */}
          {mouseCoord && canvasRef.current && (
            <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-neutral-950/80 backdrop-blur border border-white/10 font-mono text-xs text-neutral-300 flex items-center gap-2">
              <Crosshair className="w-3.5 h-3.5 text-indigo-400" />
              <span>
                x: {(((mouseCoord.x - (canvasRef.current.clientWidth / 2 + origin.x)) / scale)).toFixed(2)}
              </span>
              <span>·</span>
              <span>
                y: {MathEvaluator.evaluateFunction(
                  activeExpr,
                  (mouseCoord.x - (canvasRef.current.clientWidth / 2 + origin.x)) / scale,
                  'rad'
                ).toFixed(2)}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
