import React, { useState } from 'react';
import { HistoryItem } from '../types';
import { X, Trash2, Download, Copy, Check, CornerDownLeft, History, Calculator, Atom } from 'lucide-react';
import { SwipeableTabContainer, TabItem } from './SwipeableTabContainer';

interface HistoryTapeModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: HistoryItem[];
  onSelectResult: (val: string) => void;
  onClearHistory: () => void;
}

export const HistoryTapeModal: React.FC<HistoryTapeModalProps> = ({
  isOpen,
  onClose,
  history,
  onSelectResult,
  onClearHistory,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<'all' | 'calc' | 'physics'>('all');

  if (!isOpen) return null;

  const handleCopy = (item: HistoryItem) => {
    navigator.clipboard.writeText(`${item.expression} = ${item.result}`);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleExport = () => {
    const textContent = history
      .map(
        (h) =>
          `[${new Date(h.timestamp).toLocaleTimeString()}] ${h.expression} = ${h.result} (${h.mode || 'calc'})`
      )
      .join('\n');

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `omni-calc-history-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const historyTabs: TabItem[] = [
    { id: 'all', label: 'All', icon: History, badge: history.length },
    {
      id: 'calc',
      label: 'Calculator',
      icon: Calculator,
      badge: history.filter((h) => h.mode === 'calc' || h.mode === 'standard' || !h.mode).length,
    },
    {
      id: 'physics',
      label: 'Physics',
      icon: Atom,
      badge: history.filter((h) => h.mode === 'physics').length,
    },
  ];

  const displayedHistory = history.filter((item) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'calc') return item.mode === 'calc' || item.mode === 'standard' || !item.mode;
    if (activeFilter === 'physics') return item.mode === 'physics';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg rounded-[32px] sm:rounded-[36px] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[85vh] transition-all"
        style={{
          backgroundColor: 'var(--m3-surface-container-low)',
          color: 'var(--m3-on-surface)',
        }}
      >
        {/* M3 Expressive Drag Pill Handle */}
        <div className="pt-3 pb-1 flex justify-center">
          <div className="w-10 h-1 rounded-full opacity-40" style={{ backgroundColor: 'var(--m3-outline)' }} />
        </div>

        {/* Header */}
        <div className="px-6 py-3 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <h3 className="font-bold text-lg leading-tight" style={{ color: 'var(--m3-on-surface)' }}>
              Calculation Tape
            </h3>
            <span
              className="text-xs px-2.5 py-0.5 rounded-full font-mono font-semibold"
              style={{
                backgroundColor: 'var(--m3-surface-container-high)',
                color: 'var(--m3-primary)',
              }}
            >
              {history.length}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {history.length > 0 && (
              <>
                <button
                  onClick={handleExport}
                  title="Export History"
                  className="w-9 h-9 rounded-full flex items-center justify-center transition-all active:scale-90 border border-white/5 cursor-pointer"
                  style={{
                    backgroundColor: 'var(--m3-surface-container)',
                    color: 'var(--m3-on-surface-variant)',
                  }}
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={onClearHistory}
                  title="Clear History"
                  className="w-9 h-9 rounded-full flex items-center justify-center transition-all active:scale-90 border border-white/5 cursor-pointer"
                  style={{
                    backgroundColor: 'var(--m3-tertiary-container)',
                    color: 'var(--m3-on-tertiary-container)',
                  }}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full flex items-center justify-center transition-all active:scale-90 border border-white/5 cursor-pointer"
              style={{
                backgroundColor: 'var(--m3-surface-container-high)',
                color: 'var(--m3-on-surface-variant)',
              }}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Swipeable Category Tabs */}
        <div className="px-4 pt-2">
          <SwipeableTabContainer
            tabs={historyTabs}
            activeTabId={activeFilter}
            onSelectTab={(tabId) => setActiveFilter(tabId as 'all' | 'calc' | 'physics')}
          >
            {/* History List */}
            <div className="flex-1 overflow-y-auto max-h-[50vh] p-1 space-y-2.5">
              {displayedHistory.length === 0 ? (
                <div className="py-16 text-center flex flex-col items-center gap-2 opacity-60">
                  <span className="text-sm font-medium">No calculations in this category</span>
                  <span className="text-xs">Results will automatically appear here as you calculate</span>
                </div>
              ) : (
                displayedHistory.map((item) => (
              <div
                key={item.id}
                className="group p-4 rounded-[22px] border border-white/5 transition-all flex flex-col gap-1.5"
                style={{
                  backgroundColor: 'var(--m3-surface-container)',
                }}
              >
                <div
                  className="flex items-center justify-between text-[11px] font-mono opacity-60"
                  style={{ color: 'var(--m3-on-surface-variant)' }}
                >
                  <span>{new Date(item.timestamp).toLocaleTimeString()}</span>
                  <span className="uppercase text-[10px] tracking-wider">{item.mode}</span>
                </div>

                <div
                  className="text-sm font-mono overflow-x-auto whitespace-nowrap scrollbar-none"
                  style={{ color: 'var(--m3-on-surface)' }}
                >
                  {item.expression}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span
                    className="text-lg font-mono font-bold"
                    style={{ color: 'var(--m3-primary)' }}
                  >
                    = {item.result}
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleCopy(item)}
                      title="Copy item"
                      className="w-8 h-8 rounded-full flex items-center justify-center transition-all active:scale-90 border border-white/5"
                      style={{
                        backgroundColor: 'var(--m3-surface-container-high)',
                        color: 'var(--m3-on-surface-variant)',
                      }}
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <button
                      onClick={() => {
                        onSelectResult(item.result);
                        onClose();
                      }}
                      title="Use result in calculator"
                      className="px-3 h-8 rounded-full flex items-center gap-1 text-xs font-semibold transition-all active:scale-95 border border-white/5"
                      style={{
                        backgroundColor: 'var(--m3-secondary-container)',
                        color: 'var(--m3-on-secondary-container)',
                      }}
                    >
                      <CornerDownLeft className="w-3.5 h-3.5" />
                      <span>Use</span>
                    </button>
                  </div>
                </div>
              </div>
              ))
            )}
            </div>
          </SwipeableTabContainer>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-white/5 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold rounded-full transition-all active:scale-95 shadow-sm"
            style={{
              backgroundColor: 'var(--m3-primary)',
              color: 'var(--m3-on-primary)',
            }}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
