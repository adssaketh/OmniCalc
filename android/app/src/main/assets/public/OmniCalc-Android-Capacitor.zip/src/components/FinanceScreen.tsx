import React, { useState, useEffect, useCallback } from 'react';
import { FinanceEngine } from '../engine/finance';
import { soundFx } from '../utils/audio';
import { ChevronDown, ChevronUp, ArrowLeftRight, Copy, Check, RefreshCw, Globe, TrendingUp } from 'lucide-react';
import {
  POPULAR_CURRENCIES,
  fetchLiveExchangeRates,
  convertCurrency,
  RatesData,
  DEFAULT_RATES_USD,
} from '../engine/currency';
import { SwipeableTabContainer, TabItem } from './SwipeableTabContainer';

interface FinanceScreenProps {
  soundEnabled: boolean;
  hapticEnabled: boolean;
  currencySymbol?: string;
}

type FinanceTab = 'currency' | 'loan' | 'compound' | 'tip' | 'roi';

export const FinanceScreen: React.FC<FinanceScreenProps> = ({
  soundEnabled,
  hapticEnabled,
  currencySymbol = '₹',
}) => {
  const [activeTab, setActiveTab] = useState<FinanceTab>('currency');

  // Audio helper
  const playSound = (type: 'num' | 'op' | 'toggle' = 'num') => {
    if (soundEnabled) soundFx.playClick(type);
    if (hapticEnabled) soundFx.triggerHaptic();
  };

  // Tab switch
  const handleTabSwitch = (tab: FinanceTab) => {
    playSound('toggle');
    setActiveTab(tab);
  };

  // 0. Live Currency States
  const [ratesData, setRatesData] = useState<RatesData>({
    base: 'USD',
    rates: DEFAULT_RATES_USD,
    timestamp: Date.now(),
    lastUpdatedStr: 'Loading...',
    isLive: false,
  });
  const [isRefreshingRates, setIsRefreshingRates] = useState<boolean>(false);
  const [currencyFrom, setCurrencyFrom] = useState<string>('USD');
  const [currencyTo, setCurrencyTo] = useState<string>('INR');
  const [currencyAmount, setCurrencyAmount] = useState<string>('100');
  const [currencyCopied, setCurrencyCopied] = useState<boolean>(false);

  // Fetch live exchange rates on mount
  const loadRates = useCallback(async () => {
    setIsRefreshingRates(true);
    try {
      const live = await fetchLiveExchangeRates();
      setRatesData(live);
    } catch {
      // ignore
    } finally {
      setIsRefreshingRates(false);
    }
  }, []);

  useEffect(() => {
    loadRates();
  }, [loadRates]);

  const handleManualRefreshRates = () => {
    playSound('op');
    loadRates();
  };

  const handleSwapCurrencies = () => {
    playSound('op');
    const prevFrom = currencyFrom;
    setCurrencyFrom(currencyTo);
    setCurrencyTo(prevFrom);
  };

  const parsedCurrencyAmount = parseFloat(currencyAmount) || 0;
  const currencyConversion = convertCurrency(
    parsedCurrencyAmount,
    currencyFrom,
    currencyTo,
    ratesData.rates
  );

  const fromCurrObj = POPULAR_CURRENCIES.find((c) => c.code === currencyFrom) || {
    code: currencyFrom,
    name: currencyFrom,
    symbol: currencyFrom,
    flag: '🌐',
  };

  const toCurrObj = POPULAR_CURRENCIES.find((c) => c.code === currencyTo) || {
    code: currencyTo,
    name: currencyTo,
    symbol: currencyTo,
    flag: '🌐',
  };

  const handleCopyCurrency = () => {
    playSound('op');
    navigator.clipboard.writeText(
      currencyConversion.result.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 4,
      })
    );
    setCurrencyCopied(true);
    setTimeout(() => setCurrencyCopied(false), 1800);
  };

  // Currency quick presets
  const currencyPresets = [10, 50, 100, 500, 1000, 5000, 10000];

  // Top comparison currencies (excluding current source)
  const comparisonCodes = ['INR', 'USD', 'EUR', 'GBP', 'AED', 'JPY', 'CAD', 'AUD', 'SGD', 'CNY', 'SAR']
    .filter((c) => c !== currencyFrom)
    .slice(0, 6);

  // 1. Loan States (Defaults tailored to typical loans in INR e.g. ₹10,00,000 home/car loan)
  const [loanPrincipal, setLoanPrincipal] = useState<number>(1000000);
  const [loanRate, setLoanRate] = useState<number>(8.5);
  const [loanYears, setLoanYears] = useState<number>(15);
  const [showAmortization, setShowAmortization] = useState<boolean>(false);

  // 2. Compound Interest States (e.g. SIP / Mutual Fund in INR: ₹25,000 starting + ₹10,000/mo)
  const [ciPrincipal, setCiPrincipal] = useState<number>(50000);
  const [ciMonthly, setCiMonthly] = useState<number>(10000);
  const [ciRate, setCiRate] = useState<number>(12.0);
  const [ciYears, setCiYears] = useState<number>(10);
  const [ciStepUp, setCiStepUp] = useState<number>(10);

  // 3. Tip & Split States (e.g. ₹2,400 restaurant bill)
  const [tipBill, setTipBill] = useState<number>(2400);
  const [tipPercent, setTipPercent] = useState<number>(10);
  const [tipPeople, setTipPeople] = useState<number>(4);
  const [tipRoundUp, setTipRoundUp] = useState<boolean>(false);

  // 4. ROI States
  const [roiInitial, setRoiInitial] = useState<number>(200000);
  const [roiFinal, setRoiFinal] = useState<number>(550000);
  const [roiYears, setRoiYears] = useState<number>(5);

  // Calculations
  const loanResult = FinanceEngine.calculateLoan(loanPrincipal, loanRate, loanYears);
  const ciResult = FinanceEngine.calculateCompoundInterest(ciPrincipal, ciMonthly, ciRate, ciYears, ciStepUp);
  const tipResult = FinanceEngine.calculateTip(tipBill, tipPercent, tipPeople, tipRoundUp);
  const roiResult = FinanceEngine.calculateROI(roiInitial, roiFinal, roiYears);

  // Formatting helper with Indian numbering system and Rupee symbol
  const formatMoney = (val: number, decimals: number = 2) => {
    return `${currencySymbol}${val.toLocaleString('en-IN', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    })}`;
  };

  const financeTabs: TabItem[] = [
    { id: 'currency', label: 'Currency Exchange (Live)', icon: Globe },
    { id: 'loan', label: 'Loan / EMI' },
    { id: 'compound', label: 'SIP & Compound' },
    { id: 'tip', label: 'Tip & Bill' },
    { id: 'roi', label: 'ROI & CAGR' },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col items-center select-none">
      <SwipeableTabContainer
        tabs={financeTabs}
        activeTabId={activeTab}
        onSelectTab={(tabId) => handleTabSwitch(tabId as FinanceTab)}
      >
        {/* Surface Card */}
        <div
          className="w-full rounded-[32px] sm:rounded-[36px] shadow-2xl p-4 sm:p-7 backdrop-blur-xl border border-white/10 transition-all duration-300"
          style={{
            backgroundColor: 'color-mix(in srgb, var(--m3-surface-container-low) 96%, transparent)',
          }}
        >
        {/* TAB 0: REAL-TIME CURRENCY CONVERTER */}
        {activeTab === 'currency' && (
          <div className="flex flex-col gap-5 sm:gap-6">
            {/* Live Market Status Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2.5 pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-semibold text-emerald-400 tracking-wide uppercase">
                  {ratesData.isLive ? 'Real-Time Forex Rates' : 'Forex Rates (Cached)'}
                </span>
                <span className="text-[11px] text-neutral-400">
                  • Updated {ratesData.lastUpdatedStr}
                </span>
              </div>

              <button
                onClick={handleManualRefreshRates}
                disabled={isRefreshingRates}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium text-neutral-300 hover:text-white bg-white/[0.05] hover:bg-white/10 border border-white/10 transition-colors disabled:opacity-50"
                title="Fetch latest forex exchange rates"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingRates ? 'animate-spin text-indigo-400' : ''}`} />
                <span>{isRefreshingRates ? 'Updating...' : 'Refresh Rates'}</span>
              </button>
            </div>

            {/* Main Interactive Conversion Surface */}
            <div className="grid grid-cols-1 md:grid-cols-[1fr,auto,1fr] gap-3.5 sm:gap-6 items-center">
              {/* FROM CURRENCY */}
              <div className="bg-neutral-950/80 border border-white/10 rounded-xl p-4 sm:p-5 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-neutral-400">From Currency</span>
                  <select
                    value={currencyFrom}
                    onChange={(e) => {
                      playSound('toggle');
                      setCurrencyFrom(e.target.value);
                    }}
                    className="bg-neutral-900 border border-white/15 text-xs font-medium text-neutral-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 max-w-[200px]"
                  >
                    {POPULAR_CURRENCIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.flag} {c.code} - {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xl sm:text-2xl font-mono text-neutral-400">
                    {fromCurrObj.symbol}
                  </span>
                  <input
                    type="number"
                    step="any"
                    value={currencyAmount}
                    onChange={(e) => setCurrencyAmount(e.target.value)}
                    placeholder="0"
                    className="w-full bg-transparent font-mono text-2xl sm:text-3xl font-bold text-white focus:outline-none placeholder-neutral-600"
                  />
                </div>

                <div className="text-xs text-neutral-400 truncate">
                  {fromCurrObj.flag} {fromCurrObj.name} ({fromCurrObj.code})
                </div>

                {/* Quick Presets */}
                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[11px] text-neutral-400 mr-1">Presets:</span>
                  {currencyPresets.map((val) => (
                    <button
                      key={val}
                      onClick={() => {
                        playSound('num');
                        setCurrencyAmount(val.toString());
                      }}
                      className="px-2 py-0.5 rounded text-[11px] font-mono bg-white/[0.04] hover:bg-indigo-600/30 text-neutral-300 hover:text-indigo-200 border border-white/5 transition-colors"
                    >
                      {val.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              {/* SWAP BUTTON */}
              <div className="flex justify-center -my-1 sm:my-0">
                <button
                  onClick={handleSwapCurrencies}
                  aria-label="Swap currencies"
                  title="Swap currencies"
                  className="p-3 sm:p-3.5 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg hover:shadow-indigo-500/25 transition-all transform active:scale-95"
                >
                  <ArrowLeftRight className="w-4 h-4 sm:w-5 sm:h-5 rotate-90 md:rotate-0" />
                </button>
              </div>

              {/* TO CURRENCY */}
              <div className="bg-neutral-950/80 border border-white/10 rounded-xl p-4 sm:p-5 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-neutral-400">To Currency</span>
                  <select
                    value={currencyTo}
                    onChange={(e) => {
                      playSound('toggle');
                      setCurrencyTo(e.target.value);
                    }}
                    className="bg-neutral-900 border border-white/15 text-xs font-medium text-neutral-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 max-w-[200px]"
                  >
                    {POPULAR_CURRENCIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.flag} {c.code} - {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-baseline gap-2 overflow-x-auto scrollbar-none">
                    <span className="text-xl sm:text-2xl font-mono text-indigo-400">
                      {toCurrObj.symbol}
                    </span>
                    <span className="font-mono text-2xl sm:text-3xl font-bold text-indigo-400 tracking-tight break-all">
                      {currencyConversion.result.toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 4,
                      })}
                    </span>
                  </div>

                  <button
                    onClick={handleCopyCurrency}
                    aria-label="Copy conversion result"
                    title="Copy conversion result"
                    className="p-2 rounded-lg bg-white/[0.04] hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 transition-colors shrink-0"
                  >
                    {currencyCopied ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>

                <div className="text-xs text-neutral-400 truncate">
                  {toCurrObj.flag} {toCurrObj.name} ({toCurrObj.code})
                </div>

                {/* Direct Exchange Rate Badge */}
                <div className="pt-1 flex items-center gap-1.5 text-[11px] font-mono text-neutral-300">
                  <span className="px-2 py-0.5 rounded bg-indigo-950/60 border border-indigo-500/20 text-indigo-300">
                    1 {currencyFrom} = {currencyConversion.rate.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })} {currencyTo}
                  </span>
                  <span className="text-neutral-400">•</span>
                  <span className="text-neutral-400">
                    1 {currencyTo} = {currencyConversion.inverseRate.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })} {currencyFrom}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Multi-Currency Comparison Watchlist */}
            <div className="mt-2 p-4 rounded-xl bg-neutral-950/60 border border-white/10 flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
                  <span>
                    Quick Conversion for {parsedCurrencyAmount.toLocaleString()} {currencyFrom}
                  </span>
                </span>
                <span className="text-[11px] text-neutral-400">Tap to set target</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 pt-1">
                {comparisonCodes.map((code) => {
                  const targetObj = POPULAR_CURRENCIES.find((c) => c.code === code) || {
                    code,
                    name: code,
                    symbol: code,
                    flag: '🌐',
                  };
                  const converted = convertCurrency(
                    parsedCurrencyAmount,
                    currencyFrom,
                    code,
                    ratesData.rates
                  );
                  return (
                    <button
                      key={code}
                      onClick={() => {
                        playSound('toggle');
                        setCurrencyTo(code);
                      }}
                      className={`flex flex-col p-2.5 rounded-lg border text-left transition-all ${
                        currencyTo === code
                          ? 'bg-indigo-950/50 border-indigo-500/40 text-indigo-200 shadow-sm'
                          : 'bg-white/[0.02] border-white/5 hover:bg-white/[0.06] text-neutral-300'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs text-neutral-400">
                        <span>{targetObj.flag} {code}</span>
                        <span className="text-[10px] font-mono">{targetObj.symbol}</span>
                      </div>
                      <div className="font-mono text-sm font-semibold text-white mt-1 truncate">
                        {converted.result.toLocaleString(undefined, {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 1: LOAN / MORTGAGE */}
        {activeTab === 'loan' && (
          <div className="flex flex-col gap-5 sm:gap-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5 sm:gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Loan Amount ({currencySymbol})
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-sm">
                    {currencySymbol}
                  </span>
                  <input
                    type="number"
                    value={loanPrincipal || ''}
                    onChange={(e) => setLoanPrincipal(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-white/15 rounded-xl pl-8 pr-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Interest Rate (% per year)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    value={loanRate || ''}
                    onChange={(e) => setLoanRate(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-white/15 rounded-xl px-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 pr-8"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-xs">
                    %
                  </span>
                </div>
              </div>

              <div className="sm:col-span-2 md:col-span-1">
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Tenure (Years)
                </label>
                <input
                  type="number"
                  value={loanYears || ''}
                  onChange={(e) => setLoanYears(parseFloat(e.target.value) || 0)}
                  className="w-full bg-neutral-950 border border-white/15 rounded-xl px-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Results Grid (Adaptive across screen sizes) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 p-4 rounded-xl bg-neutral-950/80 border border-white/10">
              <div className="flex flex-col">
                <span className="text-xs text-neutral-400">Monthly EMI</span>
                <span className="text-2xl sm:text-3xl font-mono font-bold text-indigo-400 mt-1 break-words">
                  {formatMoney(loanResult.monthlyPayment)}
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-neutral-400">Total Interest Payable</span>
                <span className="text-xl sm:text-2xl font-mono font-bold text-amber-400 mt-1 break-words">
                  {formatMoney(loanResult.totalInterest)}
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-neutral-400">Total Payment (Principal + Interest)</span>
                <span className="text-xl sm:text-2xl font-mono font-bold text-neutral-100 mt-1 break-words">
                  {formatMoney(loanResult.totalPayment)}
                </span>
              </div>
            </div>

            {/* Proportion Bar */}
            {loanResult.totalPayment > 0 && (
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between text-xs font-mono text-neutral-400">
                  <span>
                    Principal: {((loanPrincipal / loanResult.totalPayment) * 100).toFixed(1)}%
                  </span>
                  <span>
                    Interest: {((loanResult.totalInterest / loanResult.totalPayment) * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="w-full h-3 bg-neutral-800 rounded-full overflow-hidden flex">
                  <div
                    className="h-full bg-indigo-500 transition-all duration-300"
                    style={{ width: `${(loanPrincipal / loanResult.totalPayment) * 100}%` }}
                    title="Principal"
                  />
                  <div
                    className="h-full bg-amber-500 transition-all duration-300"
                    style={{ width: `${(loanResult.totalInterest / loanResult.totalPayment) * 100}%` }}
                    title="Total Interest"
                  />
                </div>
              </div>
            )}

            {/* Amortization Schedule Accordion */}
            <div className="border-t border-white/10 pt-4">
              <button
                onClick={() => {
                  playSound('toggle');
                  setShowAmortization(!showAmortization);
                }}
                className="flex items-center justify-between w-full text-xs font-semibold text-neutral-300 hover:text-white py-2"
              >
                <span>Annual Amortization Schedule ({loanResult.schedule.length} years)</span>
                {showAmortization ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>

              {showAmortization && (
                <div className="mt-3 overflow-x-auto max-h-64 scrollbar-thin border border-white/10 rounded-xl">
                  <table className="w-full min-w-[500px] text-left text-xs font-mono">
                    <thead className="bg-neutral-950 text-neutral-400 sticky top-0 border-b border-white/10">
                      <tr>
                        <th className="py-2.5 px-3">Year</th>
                        <th className="py-2.5 px-3">Annual Payment</th>
                        <th className="py-2.5 px-3">Principal Paid</th>
                        <th className="py-2.5 px-3">Interest Paid</th>
                        <th className="py-2.5 px-3">Outstanding Balance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {loanResult.schedule.map((row) => (
                        <tr key={row.period} className="hover:bg-white/[0.02]">
                          <td className="py-2 px-3 text-neutral-300">Year {row.period}</td>
                          <td className="py-2 px-3 text-neutral-200">{formatMoney(row.payment, 0)}</td>
                          <td className="py-2 px-3 text-indigo-400">{formatMoney(row.principal, 0)}</td>
                          <td className="py-2 px-3 text-amber-400">{formatMoney(row.interest, 0)}</td>
                          <td className="py-2 px-3 text-neutral-300">{formatMoney(row.balance, 0)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: SIP & COMPOUND SAVINGS */}
        {activeTab === 'compound' && (
          <div className="flex flex-col gap-5 sm:gap-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3.5 sm:gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Initial Deposit ({currencySymbol})
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-sm">
                    {currencySymbol}
                  </span>
                  <input
                    type="number"
                    value={ciPrincipal || ''}
                    onChange={(e) => setCiPrincipal(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-white/15 rounded-xl pl-8 pr-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Starting Monthly SIP ({currencySymbol})
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-sm">
                    {currencySymbol}
                  </span>
                  <input
                    type="number"
                    value={ciMonthly || ''}
                    onChange={(e) => setCiMonthly(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-white/15 rounded-xl pl-8 pr-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Annual Step-Up (%)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="1"
                    min="0"
                    value={ciStepUp}
                    onChange={(e) => setCiStepUp(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-neutral-950 border border-white/15 rounded-xl px-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 pr-8"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-xs">
                    %
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Expected Return (% / yr)
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={ciRate || ''}
                  onChange={(e) => setCiRate(parseFloat(e.target.value) || 0)}
                  className="w-full bg-neutral-950 border border-white/15 rounded-xl px-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Duration (Years)
                </label>
                <input
                  type="number"
                  value={ciYears || ''}
                  onChange={(e) => setCiYears(parseFloat(e.target.value) || 0)}
                  className="w-full bg-neutral-950 border border-white/15 rounded-xl px-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Quick Step-Up Presets */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="text-neutral-400">Step-Up Presets:</span>
              {[0, 5, 10, 15, 20].map((pct) => (
                <button
                  key={pct}
                  onClick={() => {
                    playSound('num');
                    setCiStepUp(pct);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-mono transition-all ${
                    ciStepUp === pct
                      ? 'bg-indigo-600 text-white font-bold'
                      : 'bg-white/[0.05] text-neutral-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {pct === 0 ? '0% (No Step-up)' : `+${pct}% / yr`}
                </button>
              ))}
              {ciStepUp > 0 && (
                <span className="text-indigo-400 text-[11px] ml-auto">
                  Monthly SIP increases to {formatMoney(ciResult.yearlyBreakdown[ciResult.yearlyBreakdown.length - 1]?.monthlyContribution || ciMonthly, 0)}/mo by Year {ciYears}
                </span>
              )}
            </div>

            {/* Results Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 p-4 rounded-xl bg-neutral-950/80 border border-white/10">
              <div className="flex flex-col">
                <span className="text-xs text-neutral-400">Total Future Wealth</span>
                <span className="text-2xl sm:text-3xl font-mono font-bold text-emerald-400 mt-1 break-words">
                  {formatMoney(ciResult.endBalance, 0)}
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-neutral-400">Total Amount Invested</span>
                <span className="text-xl sm:text-2xl font-mono font-bold text-neutral-200 mt-1 break-words">
                  {formatMoney(ciResult.totalInvested, 0)}
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-neutral-400">Wealth Gain (Interest Accrued)</span>
                <span className="text-xl sm:text-2xl font-mono font-bold text-indigo-400 mt-1 break-words">
                  {formatMoney(ciResult.totalInterest, 0)}
                </span>
              </div>
            </div>

            {/* Progression Table */}
            <div className="overflow-x-auto max-h-56 scrollbar-thin border border-white/10 rounded-xl">
              <table className="w-full min-w-[540px] text-left text-xs font-mono">
                <thead className="bg-neutral-950 text-neutral-400 sticky top-0 border-b border-white/10">
                  <tr>
                    <th className="py-2.5 px-3">Year</th>
                    <th className="py-2.5 px-3">Monthly SIP</th>
                    <th className="py-2.5 px-3">Total Invested</th>
                    <th className="py-2.5 px-3">Interest Gained</th>
                    <th className="py-2.5 px-3">Total Corpus</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {ciResult.yearlyBreakdown.map((row) => (
                    <tr key={row.year} className="hover:bg-white/[0.02]">
                      <td className="py-2 px-3 text-neutral-300">Year {row.year}</td>
                      <td className="py-2 px-3 text-neutral-400">{row.year === 0 ? '-' : `${formatMoney(row.monthlyContribution, 0)}/mo`}</td>
                      <td className="py-2 px-3 text-neutral-300">{formatMoney(row.deposits, 0)}</td>
                      <td className="py-2 px-3 text-indigo-400">{formatMoney(row.interestAccrued, 0)}</td>
                      <td className="py-2 px-3 font-semibold text-emerald-400">{formatMoney(row.balance, 0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: TIP & BILL SPLIT */}
        {activeTab === 'tip' && (
          <div className="flex flex-col gap-5 sm:gap-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 sm:gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Bill Subtotal ({currencySymbol})
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-sm">
                    {currencySymbol}
                  </span>
                  <input
                    type="number"
                    step="1"
                    value={tipBill || ''}
                    onChange={(e) => setTipBill(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-white/15 rounded-xl pl-8 pr-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Tip Percentage (%)
                </label>
                <div className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto scrollbar-none">
                  {[5, 10, 15, 18, 20].map((pct) => (
                    <button
                      key={pct}
                      onClick={() => {
                        playSound('num');
                        setTipPercent(pct);
                      }}
                      className={`flex-1 min-w-[36px] py-2 text-xs font-mono font-medium rounded-lg transition-all ${
                        tipPercent === pct
                          ? 'bg-indigo-600 text-white font-bold'
                          : 'bg-white/[0.05] text-neutral-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Split With (People)
                </label>
                <input
                  type="number"
                  min="1"
                  value={tipPeople || 1}
                  onChange={(e) => setTipPeople(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full bg-neutral-950 border border-white/15 rounded-xl px-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Results Display */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div className="p-4 sm:p-5 rounded-xl bg-neutral-950/80 border border-white/10 flex flex-col justify-between">
                <div>
                  <span className="text-xs text-neutral-400 font-medium">Per Person Share</span>
                  <div className="text-2xl sm:text-4xl font-mono font-bold text-emerald-400 mt-2 break-words">
                    {formatMoney(tipResult.perPersonTotal)}
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-white/10 flex justify-between text-xs font-mono text-neutral-400">
                  <span>Base: {formatMoney(tipResult.perPersonBase)}</span>
                  <span>Tip: {formatMoney(tipResult.perPersonTip)}</span>
                </div>
              </div>

              <div className="p-4 sm:p-5 rounded-xl bg-neutral-950/80 border border-white/10 flex flex-col justify-between">
                <div>
                  <span className="text-xs text-neutral-400 font-medium">Total Bill + Tip</span>
                  <div className="text-2xl sm:text-4xl font-mono font-bold text-white mt-2 break-words">
                    {formatMoney(tipResult.billTotal)}
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-white/10 flex justify-between text-xs font-mono text-neutral-400">
                  <span>Tip Total: {formatMoney(tipResult.tipTotal)}</span>
                  <label className="flex items-center gap-1.5 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={tipRoundUp}
                      onChange={(e) => {
                        playSound('toggle');
                        setTipRoundUp(e.target.checked);
                      }}
                      className="rounded border-white/20 bg-neutral-900 text-indigo-600 focus:ring-0"
                    />
                    <span className="text-[11px] text-neutral-300">Round up</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: ROI & CAGR */}
        {activeTab === 'roi' && (
          <div className="flex flex-col gap-5 sm:gap-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 sm:gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Initial Capital ({currencySymbol})
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-sm">
                    {currencySymbol}
                  </span>
                  <input
                    type="number"
                    value={roiInitial || ''}
                    onChange={(e) => setRoiInitial(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-white/15 rounded-xl pl-8 pr-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Final Value ({currencySymbol})
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-sm">
                    {currencySymbol}
                  </span>
                  <input
                    type="number"
                    value={roiFinal || ''}
                    onChange={(e) => setRoiFinal(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-white/15 rounded-xl pl-8 pr-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-400 mb-1.5">
                  Investment Period (Years)
                </label>
                <input
                  type="number"
                  value={roiYears || ''}
                  onChange={(e) => setRoiYears(parseFloat(e.target.value) || 0)}
                  className="w-full bg-neutral-950 border border-white/15 rounded-xl px-3.5 py-2.5 font-mono text-base text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Results Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 p-4 sm:p-5 rounded-xl bg-neutral-950/80 border border-white/10">
              <div className="flex flex-col">
                <span className="text-xs text-neutral-400">Total ROI</span>
                <span
                  className={`text-2xl sm:text-3xl font-mono font-bold mt-1 break-words ${
                    roiResult.roiPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {roiResult.roiPercent >= 0 ? '+' : ''}
                  {roiResult.roiPercent.toFixed(2)}%
                </span>
              </div>

              <div className="flex flex-col">
                <span className="text-xs text-neutral-400">Annualized Return (CAGR)</span>
                <span className="text-xl sm:text-2xl font-mono font-bold text-indigo-400 mt-1 break-words">
                  {roiResult.cagrPercent.toFixed(2)}% / yr
                </span>
              </div>

              <div className="flex flex-col">
                <span className="text-xs text-neutral-400">Net Profit / Gain</span>
                <span
                  className={`text-xl sm:text-2xl font-mono font-bold mt-1 break-words ${
                    roiResult.gainLoss >= 0 ? 'text-neutral-100' : 'text-rose-400'
                  }`}
                >
                  {formatMoney(roiResult.gainLoss)}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </SwipeableTabContainer>
    </div>
  );
};
