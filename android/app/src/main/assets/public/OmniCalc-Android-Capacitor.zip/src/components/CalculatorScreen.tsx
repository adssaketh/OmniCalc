import React, { useState, useEffect, useCallback } from 'react';
import { AngleMode, HistoryItem } from '../types';
import { MathEvaluator } from '../engine/evaluator';
import { soundFx } from '../utils/audio';
import { Copy, Check, Delete, CornerDownLeft, Sparkles, ChevronUp } from 'lucide-react';
import { OmniCalcLogo } from './OmniCalcLogo';

interface CalculatorScreenProps {
  angleMode: AngleMode;
  onToggleAngleMode: () => void;
  decimalPrecision: number;
  soundEnabled: boolean;
  hapticEnabled: boolean;
  onAddHistory: (item: Omit<HistoryItem, 'id' | 'timestamp'>) => void;
  externalExpression?: string;
  history?: HistoryItem[];
  onOpenHistory?: () => void;
  onSelectHistoryItem?: (expr: string) => void;
}

export const CalculatorScreen: React.FC<CalculatorScreenProps> = ({
  angleMode,
  onToggleAngleMode,
  decimalPrecision,
  soundEnabled,
  hapticEnabled,
  onAddHistory,
  externalExpression,
  history,
  onOpenHistory,
  onSelectHistoryItem,
}) => {
  const [expression, setExpression] = useState<string>('0');
  const [lastQuestion, setLastQuestion] = useState<string>('');
  const [lastAnswer, setLastAnswer] = useState<string>('');
  const [memory, setMemory] = useState<number>(0);
  const [isScientific, setIsScientific] = useState<boolean>(false);
  const [isInverse, setIsInverse] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [hasEvaluated, setHasEvaluated] = useState<boolean>(false);

  // Play sound helper
  const playSound = (type: 'num' | 'op' | 'eval' | 'clear' | 'toggle' = 'num') => {
    if (soundEnabled) soundFx.playClick(type);
    if (hapticEnabled) soundFx.triggerHaptic();
  };

  // Sync external expression if loaded from history
  useEffect(() => {
    if (externalExpression !== undefined && externalExpression !== '') {
      setExpression(externalExpression);
      setLastQuestion('');
      setLastAnswer('');
      setHasEvaluated(false);
    }
  }, [externalExpression]);

  // Count unmatched open parentheses
  const getOpenParensCount = (expr: string): number => {
    let count = 0;
    for (const char of expr) {
      if (char === '(') count++;
      else if (char === ')') count--;
    }
    return Math.max(0, count);
  };

  const openParensCount = getOpenParensCount(expression);

  // Insert token into expression
  const handleInput = useCallback((token: string) => {
    playSound('num');
    setExpression((prev) => {
      if (hasEvaluated) {
        setHasEvaluated(false);
        setLastQuestion('');
        setLastAnswer('');
        // If typing an operator, continue from previous result
        if (['+', '−', '×', '÷', '^', '%'].includes(token)) {
          return prev + token;
        }
        return token;
      }

      if (prev === '0' && !['.', '+', '−', '×', '÷', '^', '%', '!', ')'].includes(token)) {
        return token;
      }

      // Prevent duplicate consecutive dots in the same number segment
      if (token === '.') {
        const segments = prev.split(/[\+\−\×\÷\^\(\)\%]/);
        const lastSegment = segments[segments.length - 1];
        if (lastSegment.includes('.')) return prev;
      }

      return prev + token;
    });
  }, [hasEvaluated, soundEnabled, hapticEnabled]);

  // Insert functions e.g. "sin("
  const handleFunction = useCallback((fn: string) => {
    playSound('op');
    setExpression((prev) => {
      if (hasEvaluated) {
        setHasEvaluated(false);
        setLastQuestion('');
        setLastAnswer('');
        return `${fn}(${prev})`;
      }
      if (prev === '0') {
        return `${fn}(`;
      }
      return `${prev}${fn}(`;
    });
  }, [hasEvaluated, soundEnabled, hapticEnabled]);

  // Smart Parentheses insertion
  const handleParentheses = useCallback(() => {
    playSound('op');
    setExpression((prev) => {
      if (hasEvaluated) {
        setHasEvaluated(false);
        setLastQuestion('');
        setLastAnswer('');
        return '(';
      }
      if (prev === '0') return '(';

      const lastChar = prev.slice(-1);
      const openCount = getOpenParensCount(prev);

      // If last char is a digit, constant, or close paren, and we have unclosed parens, close it
      if (openCount > 0 && (/[\dπeφ\)]/.test(lastChar) || lastChar === '!')) {
        return prev + ')';
      }

      // Otherwise insert open paren
      return prev + '(';
    });
  }, [hasEvaluated, soundEnabled, hapticEnabled]);

  // Clear all
  const handleClear = useCallback(() => {
    playSound('clear');
    setExpression('0');
    setLastQuestion('');
    setLastAnswer('');
    setHasEvaluated(false);
  }, [soundEnabled, hapticEnabled]);

  // Backspace
  const handleBackspace = useCallback(() => {
    playSound('clear');
    setExpression((prev) => {
      if (hasEvaluated) {
        setHasEvaluated(false);
        setLastQuestion('');
        setLastAnswer('');
        return '0';
      }
      if (prev.length <= 1) return '0';

      // Check if deleting a multi-char function name like "sin(", "sqrt(", "asin("
      const funcMatch = prev.match(/(asin|acos|atan|sinh|cosh|tanh|sqrt|cbrt|log2|log|ln|abs)\($/);
      if (funcMatch) {
        return prev.slice(0, -funcMatch[0].length) || '0';
      }

      return prev.slice(0, -1);
    });
  }, [hasEvaluated, soundEnabled, hapticEnabled]);

  // Negate sign ±
  const handleNegate = useCallback(() => {
    playSound('num');
    if (hasEvaluated) {
      setHasEvaluated(false);
      setLastQuestion('');
      setLastAnswer('');
    }
    setExpression((prev) => {
      if (prev === '0') return '0';
      if (prev.startsWith('−')) {
        return prev.slice(1);
      } else if (prev.startsWith('-')) {
        return prev.slice(1);
      } else {
        return '−' + prev;
      }
    });
  }, [hasEvaluated, soundEnabled, hapticEnabled]);

  // Evaluate final result
  const handleEvaluate = useCallback(() => {
    playSound('eval');
    try {
      let exprToEval = expression;
      const unclosed = getOpenParensCount(exprToEval);
      for (let i = 0; i < unclosed; i++) {
        exprToEval += ')';
      }

      const res = MathEvaluator.evaluate(exprToEval, angleMode);
      const formatted = MathEvaluator.formatResult(res, decimalPrecision);

      onAddHistory({
        expression: exprToEval,
        result: formatted,
        mode: isScientific ? 'Scientific' : 'Standard',
      });

      setLastQuestion(exprToEval);
      setLastAnswer(formatted);
      setExpression(formatted);
      setHasEvaluated(true);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error';
      setLastQuestion(expression);
      setLastAnswer(msg);
      setExpression(msg);
      setHasEvaluated(true);
    }
  }, [expression, angleMode, decimalPrecision, isScientific, onAddHistory, soundEnabled, hapticEnabled]);

  // Memory operations
  const handleMemory = useCallback((action: 'MC' | 'MR' | 'M+' | 'M-' | 'MS') => {
    playSound('op');
    try {
      const currentVal = MathEvaluator.evaluate(expression, angleMode);
      switch (action) {
        case 'MC':
          setMemory(0);
          break;
        case 'MR':
          setExpression(MathEvaluator.formatResult(memory, decimalPrecision));
          setHasEvaluated(true);
          break;
        case 'MS':
          setMemory(currentVal);
          break;
        case 'M+':
          setMemory((m) => m + currentVal);
          break;
        case 'M-':
          setMemory((m) => m - currentVal);
          break;
      }
    } catch {
      // ignore memory error
    }
  }, [expression, angleMode, memory, decimalPrecision, soundEnabled, hapticEnabled]);

  // Copy result to clipboard
  const handleCopy = () => {
    const textToCopy = hasEvaluated ? lastAnswer : expression;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is inside an input or textarea
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      if (e.key >= '0' && e.key <= '9') {
        handleInput(e.key);
      } else if (e.key === '.') {
        handleInput('.');
      } else if (e.key === '+') {
        handleInput('+');
      } else if (e.key === '-') {
        handleInput('−');
      } else if (e.key === '*' || e.key === 'x') {
        handleInput('×');
      } else if (e.key === '/') {
        e.preventDefault();
        handleInput('÷');
      } else if (e.key === '%') {
        handleInput('%');
      } else if (e.key === '^') {
        handleInput('^');
      } else if (e.key === '(' || e.key === ')') {
        handleInput(e.key);
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEvaluate();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Escape' || e.key === 'c' || e.key === 'C') {
        e.preventDefault();
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleInput, handleEvaluate, handleBackspace, handleClear]);

  return (
    <div className="w-full max-w-xl sm:max-w-2xl mx-auto flex flex-col justify-start select-none">
      {/* Outer Calculator Shell - M3 Expressive Card with 32px rounded corners and tonal surface */}
      <div
        className="w-full rounded-[32px] sm:rounded-[36px] p-3 sm:p-5 shadow-2xl backdrop-blur-2xl flex flex-col transition-colors border border-white/10"
        style={{
          backgroundColor: 'color-mix(in srgb, var(--m3-surface-container-low) 96%, transparent)',
        }}
      >
        {/* Sticky Number Screen - Always visible even on scrolling through keys */}
        <div
          className="sticky top-[70px] sm:top-[78px] z-30 w-full rounded-[26px] sm:rounded-[28px] p-4 sm:p-5 mb-3 flex flex-col justify-between min-h-[135px] sm:min-h-[150px] shadow-lg backdrop-blur-2xl transition-all border border-white/5"
          style={{
            backgroundColor: 'var(--m3-surface-container-lowest)',
          }}
        >
          {/* Metadata chips inside display */}
          <div className="flex items-center justify-between text-xs mb-2">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                onClick={onToggleAngleMode}
                className="px-3 py-1 rounded-full text-[11px] font-semibold transition-all duration-150 active:scale-95 border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-primary)',
                }}
                title="Switch DEG / RAD"
              >
                {angleMode.toUpperCase()}
              </button>

              {memory !== 0 && (
                <span
                  className="text-[11px] font-mono font-semibold px-2.5 py-1 rounded-full border border-white/5"
                  style={{
                    backgroundColor: 'var(--m3-secondary-container)',
                    color: 'var(--m3-on-secondary-container)',
                  }}
                >
                  M: {MathEvaluator.formatResult(memory, 2)}
                </span>
              )}

              {openParensCount > 0 && (
                <span
                  className="text-[11px] font-mono px-2.5 py-1 rounded-full border border-white/5"
                  style={{
                    backgroundColor: 'var(--m3-tertiary-container)',
                    color: 'var(--m3-on-tertiary-container)',
                  }}
                >
                  ( {openParensCount}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 text-[11px] font-medium px-3 py-1 rounded-full transition-all duration-150 active:scale-95 border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container)',
                  color: 'var(--m3-on-surface-variant)',
                }}
                title="Copy current result or expression"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Top Line: The Question that was typed (NO labels) */}
          <div
            className="text-right overflow-x-auto whitespace-nowrap scrollbar-none font-mono text-sm sm:text-base tracking-wide select-all py-0.5 min-h-[1.5rem]"
            style={{ color: 'var(--m3-outline)' }}
          >
            {hasEvaluated && lastQuestion ? (
              <span>{lastQuestion} =</span>
            ) : (
              <span className="opacity-0 select-none">0</span>
            )}
          </div>

          {/* Bottom Line: The Answer / Primary Display (NO labels) */}
          <div className="text-right flex items-baseline justify-end gap-3 overflow-x-auto whitespace-nowrap scrollbar-none py-1">
            <span
              key={hasEvaluated ? `ans-${lastAnswer}` : `expr-${expression}`}
              className={`font-mono font-semibold tracking-tight select-all transition-all ${
                hasEvaluated ? 'animate-m3-result-update' : ''
              } ${
                (hasEvaluated ? lastAnswer : expression).length > 14
                  ? 'text-2xl sm:text-3xl'
                  : 'text-3xl sm:text-4xl md:text-5xl'
              }`}
              style={{ color: 'var(--m3-on-surface)' }}
            >
              {hasEvaluated ? lastAnswer : expression}
            </span>
          </div>
        </div>

        {/* M3 Expressive Toolbar: Segmented Memory & Math Helpers */}
        <div className="flex items-center justify-between gap-1.5 sm:gap-2 mb-2.5 overflow-x-auto scrollbar-none py-0.5">
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            <button
              onClick={() => handleMemory('MC')}
              className="py-1 px-3 text-xs font-semibold rounded-full transition-all active:scale-95 border border-white/5"
              style={{
                backgroundColor: 'var(--m3-surface-container)',
                color: 'var(--m3-on-surface-variant)',
              }}
            >
              MC
            </button>
            <button
              onClick={() => handleMemory('MR')}
              className="py-1 px-3 text-xs font-semibold rounded-full transition-all active:scale-95 border border-white/5"
              style={{
                backgroundColor: memory !== 0 ? 'var(--m3-secondary-container)' : 'var(--m3-surface-container)',
                color: memory !== 0 ? 'var(--m3-on-secondary-container)' : 'var(--m3-on-surface-variant)',
              }}
            >
              MR
            </button>
            <button
              onClick={() => handleMemory('M+')}
              className="py-1 px-3 text-xs font-semibold rounded-full transition-all active:scale-95 border border-white/5"
              style={{
                backgroundColor: 'var(--m3-surface-container)',
                color: 'var(--m3-on-surface-variant)',
              }}
            >
              M+
            </button>
            <button
              onClick={() => handleMemory('M-')}
              className="py-1 px-3 text-xs font-semibold rounded-full transition-all active:scale-95 border border-white/5"
              style={{
                backgroundColor: 'var(--m3-surface-container)',
                color: 'var(--m3-on-surface-variant)',
              }}
            >
              M−
            </button>
          </div>

          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            <button
              onClick={handleParentheses}
              className="py-1 px-3 text-xs font-semibold rounded-full transition-all active:scale-95 border border-white/5"
              style={{
                backgroundColor: 'var(--m3-surface-container)',
                color: 'var(--m3-on-surface)',
              }}
              title="Insert parentheses ( )"
            >
              ( )
            </button>
            <button
              onClick={handleNegate}
              className="py-1 px-3 text-xs font-semibold rounded-full transition-all active:scale-95 border border-white/5"
              style={{
                backgroundColor: 'var(--m3-surface-container)',
                color: 'var(--m3-on-surface)',
              }}
              title="Negate ±"
            >
              ±
            </button>
            {isScientific && (
              <button
                onClick={() => setIsInverse(!isInverse)}
                className="py-1 px-3 text-xs font-semibold rounded-full transition-all active:scale-95 border border-white/5"
                style={{
                  backgroundColor: isInverse ? 'var(--m3-tertiary-container)' : 'var(--m3-surface-container)',
                  color: isInverse ? 'var(--m3-on-tertiary-container)' : 'var(--m3-on-surface-variant)',
                }}
                title="Inverse trigonometric & logarithmic functions"
              >
                2nd
              </button>
            )}
          </div>
        </div>

        {/* Quick Physics & Math Strip - Usable in standard mode with M3 rounded squircle pills */}
        <div className="grid grid-cols-8 gap-1 sm:gap-1.5 mb-2.5">
          <button
            onClick={() => handleInput('π')}
            className="py-2 text-xs font-mono font-semibold rounded-[16px] m3-key border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container)',
              color: 'var(--m3-on-surface)',
            }}
            title="Pi π ≈ 3.14159"
          >
            π
          </button>
          <button
            onClick={() => handleInput('e')}
            className="py-2 text-xs font-mono font-semibold rounded-[16px] m3-key border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container)',
              color: 'var(--m3-on-surface)',
            }}
            title="Euler's number e ≈ 2.71828"
          >
            e
          </button>
          <button
            onClick={() => handleFunction('sqrt')}
            className="py-2 text-xs font-mono font-semibold rounded-[16px] m3-key border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container)',
              color: 'var(--m3-on-surface)',
            }}
            title="Square root √x"
          >
            √x
          </button>
          <button
            onClick={() => handleInput('^2')}
            className="py-2 text-xs font-mono font-semibold rounded-[16px] m3-key border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container)',
              color: 'var(--m3-on-surface)',
            }}
            title="Square x²"
          >
            x²
          </button>
          <button
            onClick={() => handleInput('c')}
            className="py-2 text-xs font-mono font-semibold rounded-[16px] m3-key border border-white/5"
            style={{
              backgroundColor: 'var(--m3-secondary-container)',
              color: 'var(--m3-on-secondary-container)',
            }}
            title="Speed of light c = 2.99792 × 10⁸ m/s"
          >
            c
          </button>
          <button
            onClick={() => handleInput('h')}
            className="py-2 text-xs font-mono font-semibold rounded-[16px] m3-key border border-white/5"
            style={{
              backgroundColor: 'var(--m3-secondary-container)',
              color: 'var(--m3-on-secondary-container)',
            }}
            title="Planck constant h = 6.62607 × 10⁻³⁴ J·s"
          >
            h
          </button>
          <button
            onClick={() => handleInput('G')}
            className="py-2 text-xs font-mono font-semibold rounded-[16px] m3-key border border-white/5"
            style={{
              backgroundColor: 'var(--m3-secondary-container)',
              color: 'var(--m3-on-secondary-container)',
            }}
            title="Gravitational constant G = 6.6743 × 10⁻¹¹ N·m²/kg²"
          >
            G
          </button>
          <button
            onClick={() => handleInput('g')}
            className="py-2 text-xs font-mono font-semibold rounded-[16px] m3-key border border-white/5"
            style={{
              backgroundColor: 'var(--m3-secondary-container)',
              color: 'var(--m3-on-secondary-container)',
            }}
            title="Standard gravity g = 9.80665 m/s²"
          >
            g
          </button>
        </div>

        {/* Advanced Symbols Keys Drawer (Revealed via the separate button) */}
        {isScientific && (
          <div
            className="mb-3 p-3.5 sm:p-4 rounded-[28px] border border-white/10 shadow-inner transition-all animate-fadeIn"
            style={{
              backgroundColor: 'var(--m3-surface-container)',
            }}
          >
            <div className="flex items-center justify-between mb-2.5">
              <span
                className="text-xs font-semibold flex items-center gap-1.5"
                style={{ color: 'var(--m3-primary)' }}
              >
                <Sparkles className="w-3.5 h-3.5" />
                Advanced Symbols
              </span>
              {/* Symbol toggle with logo (no "Hide Advanced" text) */}
              <button
                onClick={() => {
                  playSound('toggle');
                  setIsScientific(false);
                }}
                aria-label="Toggle Advanced Symbols"
                title="Collapse Advanced Symbols"
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full transition-all duration-150 active:scale-90 border border-white/10 hover:brightness-110"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                <OmniCalcLogo className="w-4 h-4" />
                <ChevronUp className="w-3.5 h-3.5 opacity-80" />
              </button>
            </div>

            {/* Grid of Advanced Math & Physics Symbols */}
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5 sm:gap-2">
              {/* Trigonometry */}
              <button
                onClick={() => handleFunction(isInverse ? 'asin' : 'sin')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                {isInverse ? 'sin⁻¹' : 'sin'}
              </button>
              <button
                onClick={() => handleFunction(isInverse ? 'acos' : 'cos')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                {isInverse ? 'cos⁻¹' : 'cos'}
              </button>
              <button
                onClick={() => handleFunction(isInverse ? 'atan' : 'tan')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                {isInverse ? 'tan⁻¹' : 'tan'}
              </button>
              <button
                onClick={() => handleFunction(isInverse ? 'log2' : 'ln')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                {isInverse ? 'log₂' : 'ln'}
              </button>
              <button
                onClick={() => handleFunction('log')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                log₁₀
              </button>
              <button
                onClick={() => handleFunction('sqrt')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                √x
              </button>

              {/* Hyperbolic & Powers */}
              <button
                onClick={() => handleFunction('sinh')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                sinh
              </button>
              <button
                onClick={() => handleFunction('cosh')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                cosh
              </button>
              <button
                onClick={() => handleFunction('tanh')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                tanh
              </button>
              <button
                onClick={() => handleInput('^')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                xʸ
              </button>
              <button
                onClick={() => handleInput('^2')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                x²
              </button>
              <button
                onClick={() => handleInput('!')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                x!
              </button>

              {/* Math Constants & Functions */}
              <button
                onClick={() => handleInput('π')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                π
              </button>
              <button
                onClick={() => handleInput('e')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                e
              </button>
              <button
                onClick={() => handleFunction('abs')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                |x|
              </button>
              <button
                onClick={() => handleFunction('cbrt')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                ³√x
              </button>
              <button
                onClick={() => handleInput('1/(')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
              >
                1/x
              </button>
              <button
                onClick={() => handleInput('φ')}
                className="py-2.5 px-2 text-xs font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-surface-container-high)',
                  color: 'var(--m3-on-surface)',
                }}
                title="Golden ratio φ ≈ 1.618"
              >
                φ
              </button>

              {/* Physics Fundamental Constants */}
              <button
                onClick={() => handleInput('c')}
                className="py-2 px-1.5 text-xs font-mono font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-secondary-container)',
                  color: 'var(--m3-on-secondary-container)',
                }}
                title="Speed of light c = 2.99792 × 10⁸ m/s"
              >
                c
              </button>
              <button
                onClick={() => handleInput('h')}
                className="py-2 px-1.5 text-xs font-mono font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-secondary-container)',
                  color: 'var(--m3-on-secondary-container)',
                }}
                title="Planck constant h = 6.626 × 10⁻³⁴ J·s"
              >
                h
              </button>
              <button
                onClick={() => handleInput('hbar')}
                className="py-2 px-1.5 text-xs font-mono font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-secondary-container)',
                  color: 'var(--m3-on-secondary-container)',
                }}
                title="Reduced Planck constant ℏ = 1.055 × 10⁻³⁴ J·s"
              >
                ℏ
              </button>
              <button
                onClick={() => handleInput('G')}
                className="py-2 px-1.5 text-xs font-mono font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-secondary-container)',
                  color: 'var(--m3-on-secondary-container)',
                }}
                title="Gravitational constant G = 6.674 × 10⁻¹¹ N·m²/kg²"
              >
                G
              </button>
              <button
                onClick={() => handleInput('qe')}
                className="py-2 px-1.5 text-xs font-mono font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-secondary-container)',
                  color: 'var(--m3-on-secondary-container)',
                }}
                title="Elementary charge e = 1.602 × 10⁻¹⁹ C"
              >
                e
              </button>
              <button
                onClick={() => handleInput('me')}
                className="py-2 px-1.5 text-xs font-mono font-semibold rounded-[18px] m3-key border border-white/5"
                style={{
                  backgroundColor: 'var(--m3-secondary-container)',
                  color: 'var(--m3-on-secondary-container)',
                }}
                title="Electron mass mₑ = 9.109 × 10⁻³¹ kg"
              >
                mₑ
              </button>
            </div>
          </div>
        )}

        {/* Primary Calculator Keypad: Android Material 3 Expressive Squircle & Pill Keypad */}
        <div className="grid grid-cols-4 gap-2 sm:gap-2.5">
          {/* Row 1: Function / Clear Row */}
          <button
            onClick={handleClear}
            className="h-14 sm:h-16 md:h-18 text-base sm:text-lg font-bold rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container)',
              color: 'var(--m3-tertiary)',
            }}
          >
            AC
          </button>
          <button
            onClick={handleBackspace}
            className="h-14 sm:h-16 md:h-18 text-sm sm:text-base font-semibold rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container)',
              color: 'var(--m3-on-surface-variant)',
            }}
            title="Backspace"
          >
            <Delete className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
          <button
            onClick={() => handleInput('%')}
            className="h-14 sm:h-16 md:h-18 text-base sm:text-lg font-semibold rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container)',
              color: 'var(--m3-on-surface-variant)',
            }}
          >
            %
          </button>
          <button
            onClick={() => handleInput('÷')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-semibold rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-secondary-container)',
              color: 'var(--m3-on-secondary-container)',
            }}
          >
            ÷
          </button>

          {/* Row 2: 7, 8, 9, × */}
          <button
            onClick={() => handleInput('7')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            7
          </button>
          <button
            onClick={() => handleInput('8')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            8
          </button>
          <button
            onClick={() => handleInput('9')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            9
          </button>
          <button
            onClick={() => handleInput('×')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-semibold rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-secondary-container)',
              color: 'var(--m3-on-secondary-container)',
            }}
          >
            ×
          </button>

          {/* Row 3: 4, 5, 6, − */}
          <button
            onClick={() => handleInput('4')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            4
          </button>
          <button
            onClick={() => handleInput('5')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            5
          </button>
          <button
            onClick={() => handleInput('6')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            6
          </button>
          <button
            onClick={() => handleInput('−')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-semibold rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-secondary-container)',
              color: 'var(--m3-on-secondary-container)',
            }}
          >
            −
          </button>

          {/* Row 4: 1, 2, 3, + */}
          <button
            onClick={() => handleInput('1')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            1
          </button>
          <button
            onClick={() => handleInput('2')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            2
          </button>
          <button
            onClick={() => handleInput('3')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            3
          </button>
          <button
            onClick={() => handleInput('+')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-semibold rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-secondary-container)',
              color: 'var(--m3-on-secondary-container)',
            }}
          >
            +
          </button>

          {/* Row 5: Separate Button to get Advanced Symbols Keys + 0 + . + Hero Equals Pill */}
          <button
            onClick={() => {
              playSound('toggle');
              setIsScientific(!isScientific);
            }}
            className="h-14 sm:h-16 md:h-18 px-2 text-xs sm:text-sm font-semibold rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center gap-1.5 transition-all border border-white/5"
            style={{
              backgroundColor: isScientific
                ? 'var(--m3-tertiary-container)'
                : 'var(--m3-surface-container)',
              color: isScientific
                ? 'var(--m3-on-tertiary-container)'
                : 'var(--m3-primary)',
            }}
            title={isScientific ? 'Hide advanced symbols keys' : 'Show advanced symbols keys (trig, powers, physics)'}
          >
            <OmniCalcLogo className="w-4 h-4 shrink-0" />
            <span className="font-mono font-bold tracking-tight">{isScientific ? 'fx ON' : 'fx ADV'}</span>
          </button>

          <button
            onClick={() => handleInput('0')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-medium rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            0
          </button>
          <button
            onClick={() => handleInput('.')}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-mono font-bold rounded-[24px] sm:rounded-[28px] m3-key flex items-center justify-center border border-white/5"
            style={{
              backgroundColor: 'var(--m3-surface-container-high)',
              color: 'var(--m3-on-surface)',
            }}
          >
            .
          </button>

          {/* Material 3 Expressive HERO Equals Button Pill */}
          <button
            onClick={handleEvaluate}
            className="h-14 sm:h-16 md:h-18 text-2xl sm:text-3xl font-bold rounded-[24px] sm:rounded-[28px] sm:rounded-full m3-key shadow-lg flex items-center justify-center gap-1.5 border border-white/10"
            style={{
              backgroundColor: 'var(--m3-primary)',
              color: 'var(--m3-on-primary)',
            }}
          >
            <span>=</span>
            <CornerDownLeft className="w-4 h-4 sm:w-5 sm:h-5 opacity-75" />
          </button>
        </div>
      </div>
    </div>
  );
};
